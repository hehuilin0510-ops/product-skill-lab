#!/usr/bin/env python3
"""Create a same-dimension share PNG under a strict byte limit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image


PALETTE_STEPS = (256, 192, 128, 96, 64, 48, 32, 24, 16, 12, 8, 6, 4)


def save_optimized(image: Image.Image, output: Path) -> None:
    image.save(output, format="PNG", optimize=True, compress_level=9)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Optimize a PNG without resizing; fail if the byte target cannot be met."
    )
    parser.add_argument("input_png", type=Path)
    parser.add_argument("output_png", type=Path)
    parser.add_argument("--target-bytes", type=int, default=4_900_000)
    args = parser.parse_args()

    source = args.input_png.expanduser().resolve()
    output = args.output_png.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"input does not exist: {source}")
    if source == output:
        raise SystemExit("input and output must be different; keep the lossless original")
    if args.target_bytes <= 0:
        raise SystemExit("--target-bytes must be positive")

    output.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as opened:
        opened.load()
        original_size = opened.size
        has_alpha = "A" in opened.getbands() or "transparency" in opened.info
        working = opened.convert("RGBA" if has_alpha else "RGB")

    save_optimized(working, output)
    selected: int | str | None = "lossless"
    if output.stat().st_size > args.target_bytes:
        # MAXCOVERAGE retains small, high-contrast UI accents (for example blue
        # interaction arrows) that frequency-weighted median cut can turn gray.
        method = Image.Quantize.FASTOCTREE if working.mode == "RGBA" else Image.Quantize.MAXCOVERAGE
        selected = None
        for colors in PALETTE_STEPS:
            candidate = working.quantize(colors=colors, method=method, dither=Image.Dither.NONE)
            save_optimized(candidate, output)
            if output.stat().st_size <= args.target_bytes:
                selected = colors
                break
        if selected is None:
            output.unlink(missing_ok=True)
            raise SystemExit(
                "unable to meet target without resizing; keep the original and ask whether a larger limit or smaller preview is acceptable"
            )

    with Image.open(output) as checked:
        if checked.size != original_size:
            output.unlink(missing_ok=True)
            raise SystemExit("dimension check failed")

    result = {
        "input": str(source),
        "output": str(output),
        "dimensions": list(original_size),
        "target_bytes": args.target_bytes,
        "output_bytes": output.stat().st_size,
        "palette": selected,
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
