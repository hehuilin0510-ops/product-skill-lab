# Family Glory Expedition PRD Pattern

Use this reference when updating Chinese PRDs for `家族荣耀远征`, `守擂战`, `皇城 PK 秒杀`, or related activity modules.

## Document Style

- Keep the table structure: `需求模块 / 原型截图 / 需求描述`.
- Use dynamic numbered requirement descriptions and include only source-backed sections.
- Possible cell sections when relevant:
  - `1. 页面说明：...`
  - `i. ...`
  - `ii. ...`
  - `2. 展示规则：...`
  - `3. 交互说明：...`
- Do not add `异常说明/限制` unless the current source explicitly defines the exception or restriction.
- Keep module screenshots in the middle column. Crop the specific module when possible instead of inserting the full prototype sheet.
- Keep completeness and review checks internal; do not output `评审检查点` in the formal PRD.

## Evidence Boundary

- Treat the rules below as reusable only when they are evidenced by the current source or explicitly confirmed by the user.
- Use unmatched items to detect a conflict or formulate a clarification question, never to fill a missing rule automatically.

## Stable Terminology

- Use `守擂战`, `守擂家族`, `挑战家族`, `擂主奖励`.
- Treat prototype text `守播战` as `守擂战` unless the user explicitly says otherwise.
- Keep `守擂战` and `皇城 PK 秒杀` as independent玩法 modules.
- Do not mix `票数` and `收礼值`:
  - 守擂战 uses `票数`.
  - 皇城 PK 秒杀 uses `收礼值`.

## 守擂战 Rules

- VS 主对手取 `挑战榜 Top1`.
- 阶段结束后按双方票数判定：
  - 守擂家族票数高于挑战家族：守擂成功 / 挑战失败。
  - 挑战家族票数高于守擂家族：守擂失败 / 挑战成功。
- `我的家族位置/排名` must be documented as an independent display module when shown in prototype:
  - 当前排名
  - 当前票数
  - 距擂主还差票数
  - 未上榜/差距不可计算 fallback

## 守擂奖励弹层

- The reward popup only shows 守擂战 rewards, not 皇城 PK 秒杀 rewards.
- Collapsed state should support dynamic current-reward display:
  - 未成为擂主 or 连续守擂成功 0 次: show 首登擂主奖励.
  - 连续守擂成功 1 次: show 第二档奖励.
  - 连续守擂成功 2 次: show 第三档奖励.
  - 连续守擂成功 3 次及以上: show 第四档/最高档奖励.
  - 最高档完成后: continue showing 最高档奖励及对应状态; do not hide the reward entry.
- Expanded state still shows all 守擂奖励.
- Backend/data source:
  - Prefer backend returning the current collapsed-state reward tier.
  - If backend only returns 连续守擂成功次数, map it using the rules above.
- If the current source does not define missing reward-configuration behavior, ask the user before writing. Do not infer hiding, falling through to another tier, or displaying `暂无配置`.

## 皇城 PK 秒杀 Rules

- 皇城 PK 秒杀 is independent from 守擂战.
- Use 收礼值 for progress and seconds-kill conditions.
- Known rules:
  - Complete 5 energy collections to enter matching.
  - Match an enemy camp主播 of similar level.
  - 30-minute 收礼值 PK.
  - `1 金豆收礼值 = 1 PK 战斗力`.
  - 秒杀触发: after 8 minutes, one side reaches 200% of the other side and the losing side exceeds the minimum task value.
  - 秒杀 countdown lasts 2 minutes.
  - If the losing side narrows the gap and no longer meets the seconds-kill condition, warning is lifted and PK continues.
  - Daily seconds-kill cap: 10 per主播.

## 轮播入口资源位

- Single resource slot: only one入口 card is displayed at a time.
- Entry state, copy, data, and jump parameters are backend-delivered.
- 守擂入口 audience:
  - 正在守擂的家族.
  - 正在挑战的 Top1-3 家族.
- 守擂入口 states:
  - 家族守擂中
  - 挑战擂主中
  - 挑战成功
  - 挑战失败
  - 守擂成功
  - 守擂失败
- 皇城 PK 秒杀入口 audience:
  - 当前皇城 PK 双方主播所属家族成员.
- 皇城 PK 秒杀入口 states:
  - 即将秒杀对方
  - 即将被对方秒杀
  - 秒杀成功
  - 已被秒杀
- Conflict rule:
  - If a user satisfies both 守擂入口 and 秒杀入口 conditions, show 秒杀入口 first.
  - If no 秒杀入口 but 守擂入口 matches, show 守擂入口.
  - If neither matches, use only the behavior confirmed in the current source. If absent, ask rather than choosing hidden or backend fallback behavior.

## Backend Reward Configuration

- If the PRD includes backend config rows, preserve them unless the user asks to change backend structure.
- 守擂战奖励 configuration should remain independent from 皇城 PK 秒杀 rewards.
- When adding display-only logic, state that it does not change reward settlement or backend configuration unless explicitly requested.
