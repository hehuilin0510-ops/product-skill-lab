# Activity PRD Document Structure

Use this reference for the document-level layout of Chinese activity PRDs. It is based on the verified structure of the TAPD activity requirement `8月公会新活动` and is a formatting template, not a source for another activity's business values.

## Canonical Order

1. `一、活动基础信息`
   - 活动标题
   - 上线地区
   - 活动时间 and governing time zone
   - 多语言、数值表、设计清单 links when present
2. `二、活动对象`
   - `活动对象：`
   - `黑名单逻辑&名单：`
   - `黑名单逻辑：`
   - `黑名单ID：`
   - `版本限制：` when the current source defines it
3. `三、背景`
4. `四、思维导图`
5. `五、原型图`
6. `六、需求详情`
   - `● 活动页面与玩法需求`
   - `● 后台配置需求` when applicable
   - Render `活动页面与玩法需求` in the user-selected mode: either the `需求模块 / 原型截图 / 需求描述` three-column table or an integrated prototype-flow board.
   - Keep `后台配置需求` as its existing requirement table unless the user explicitly requests another format for that subsection.

## Placement Rules

- Keep activity-wide audience, blacklist, and version rules only in `二、活动对象`.
- Never duplicate those baseline rules in a generic `活动公共框架`, `活动范围`, `后台配置要求`, or `活动基础与公共配置` table row.
- Keep an eligibility or blacklist rule inside a table only when it is specific to that exact module and differs from the activity-wide baseline.
- The selected page-facing requirement surface contains page behavior,玩法, interactions, data definitions, and confirmed settlement behavior; it does not replace the document-level baseline sections.
- Changing between three-column and integrated-board modes affects only `● 活动页面与玩法需求`. Preserve `● 后台配置需求` and its table unless the user explicitly includes them in the change.
- In integrated-board mode, use the board as the full page-facing PRD surface rather than adding a second, thinner summary table below it.
- When migrating an existing document, preserve the existing version table and all section content, insert missing top-level sections, renumber later headings, and remove only the duplicated baseline wording from tables.

## Generic Example

```text
一、活动基础信息
活动标题：[current source]
上线地区：[current source]
活动时间：[current source]

二、活动对象
活动对象：[current source]
黑名单逻辑&名单：
黑名单逻辑：[current source]
黑名单ID：[current source]
版本限制：[current source, when applicable]

三、背景
四、思维导图
五、原型图
六、需求详情
● 活动页面与玩法需求
● 后台配置需求
```

Do not copy the example placeholders or the reference activity's dates, audience, blacklist policy, IDs, or version rules into another PRD.
