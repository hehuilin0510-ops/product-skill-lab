# Axure Activity Requirement Patterns

Read this reference when a PRD/TAPD update is based on a complex Axure activity prototype with staged rankings, multiple identities, live-room panels, invitation flows, or mixed regional/global timing. For guild/agent competitions and multi-stage ranking activities, this is the priority reference for requirement completeness and interaction expression.

Use every matrix and checklist in this file internally. They identify evidence to look for and questions to ask; they do not authorize writing unspecified states, failures, Toasts, fallbacks, or review checks into the formal PRD.

## Priority Trigger And Fixed Analysis Order

Use this reference first when the activity contains one or more of these structures: guild/agent competition, multiple stages, regional and global rankings, live-room panels, invitation/assistance, or draws.

Analyze in this exact order:

1. whole-activity lifecycle;
2. module and stage states;
3. time basis;
4. actor and data ownership;
5. ranking dimension and snapshot behavior;
6. display rules;
7. complete interaction chains;
8. reward delivery and settlement;
9. dialogs, bubbles, public messages, IM, and PUSH.

Do not start writing detailed interaction prose until the evidence-backed parts of the matrices below are complete and boundary-changing gaps have been clarified. Leave non-applicable cells empty internally rather than inventing behavior.

## Axure Source Intake

- Treat `.rp` interaction/business copy, widget states, embedded assets, and visible layout as evidence.
- Prioritize dialog, button, state, task, reward, Toast, and routing copy over decorative page titles.
- Merge fragmented configurable runs such as `[001]` back into the surrounding sentence before interpreting the rule.
- Record uncertain or duplicate extracted strings as review items; do not turn extraction noise into product logic.
- Do not require a separate Axure-analysis skill. Perform this evidence pass inside the current PRD/TAPD workflow.

## Requirement Decomposition

### Lifecycle matrix

Build a matrix before writing page rules:

| Scope | States to define |
|---|---|
| Whole activity | check preview, active, ended, network error, blacklist when evidenced or applicable |
| Module | unopened, active, completed, unavailable |
| Stage | current, future, historical, eliminated |
| Data | check loading, normal, empty, unranked, failed when evidenced or applicable |

Do not assume that activity start means every module or stage has started.

### Time and actor matrix

For each ranking or module, record:

- time basis: viewer local, target region local, or global unified time;
- data owner: logged-in user, logged-in host, current live host, logged-in agent, or current host's agent;
- ranking dimension: daily, stage, cumulative, regional, or global;
- snapshot behavior: realtime or settled history.

This matrix is mandatory when viewer and host regions can be on different local dates.

### Ranking dimension matrix

For every ranking, record at least:

| Ranking | Region/global | Daily/stage/cumulative | Realtime/history | Data owner | Sticky-row owner | Settlement |
|---|---|---|---|---|---|---|

Do not combine two rankings into one row when their clocks, owners, snapshots, or settlement rules differ.

### Interaction chain matrix

For every clickable control, record:

| Page + exact control | Precondition | Destination | Default position/data owner | Success result | Confirmed failure/Toast | Close/back | Data/server change |
|---|---|---|---|---|---|---|---|

### Invitation/assistance state matrix

When invitation or assistance exists, cover:

| State | Trigger/check | Visible result | Server effect | Reset/expiry |
|---|---|---|---|---|
| empty/search | eligible target lookup | empty or result row | none | current day/session |
| send success | limits and relationship checks pass | sent feedback | invitation created | configured expiry |
| received | valid invitation exists | invitation row | none | daily or configured reset |
| accept success | both sides are available | accepted/bound state | relationship created | configured duration |
| blocked | limit, expired, already bound, or target unavailable | exact Toast | no mutation | retain current state |

## Display Rules

- Treat a ranking page as a state system, not only a list. Define current/future/history stage controls, countdown, loading size, maximum rows, TOP rewards, badges, and sticky personal information.
- Keep unranked sticky information visible when required: avatar, name, score `0`, and unranked fallback.
- Check whether the source defines avatar routing by online state. Do not assume live-room versus profile routing without evidence.
- For live-room entry, state whose data the half-screen shows. Current-host ranking and logged-in-user ranking must not share one vague rule.
- Check whether the source defines panel-carousel eligibility and hidden-panel behavior. Do not assume that hidden panels are removed from carousel positions unless evidenced.
- Separate a reward value, a conditional help icon, a page-level reward-preview control, the help popup, and settlement logic. A help icon can be conditional, such as appearing only after a reward cap is reached.

## Interaction Rules

Write each chain as:

`exact visible control + page` → `precondition` → `destination` → `default tab/data owner` → `success result` → `failure toast/empty state` → `close/back destination` → `data refresh or server-state change`.

High-risk chains:

- current stage vs future-stage toast vs historical snapshot;
- regional/global tab visibility and default positioning;
- avatar live-room/profile routing;
- date/stage selectors;
- invitation search, send, accept, expiry, daily limit, existing relationship, and daily reset;
- draw once/all, result popup, record list, and no-record state;
- panel card to half-screen/play page/gift panel;
- conditional `?` to a confirmed context-specific explanation popup.

## Reward Rules

For every reward surface, state independently:

- whether it is preview, draw result, or stage settlement;
- recipient;
- eligibility threshold;
- auto issue vs manual claim;
- issue time;
- issued/claimed visual state;
- cap behavior and whether a cap-help icon appears;
- abnormal补发 or risk-control behavior, only when current evidence defines it.

Do not normalize all rewards to one delivery method.

## Notification Rules

For live-room dialogs, bubbles, public messages, IM, or PUSH, require:

1. recipient and visibility;
2. trigger event/time;
3. frequency and expiry;
4. exact copy;
5. click destination and default position.

## Internal Review Checks

- activity/module/stage start conditions are separate;
- regional and global clocks are bound to the right data;
- viewer and current-host data are not mixed;
- future stages cannot expose formal data;
- historical stages use snapshots;
- unranked sticky information follows the confirmed fallback;
- hidden panels do not occupy carousel slots;
- conditional help icons are not converted into permanent reward controls;
- manual and automatic rewards are not mixed;
- all messages have recipient, timing, frequency, copy, and destination.

## Knowledge Boundary

- Reuse state completeness, interaction-chain structure, actor/time separation, and visual evidence discipline.
- Keep these checks out of the formal PRD and never turn an absent checklist item into a new exception section.
- Do not inherit dates, time windows, thresholds, advancement counts, reward values, caps, or frequency limits from the reference activity.
- Replace configurable values with placeholders or current-source configuration.
- Activities outside the matching guild/agent or multi-stage ranking pattern may consult this reference, but must not be forced into its structure.
