# Activity PRD Completeness Standard

Source: user-provided Enterprise WeChat document, force-refreshed and normalized into reusable activity PRD checks on 2026-08-07.

Use this reference in two modes. During PRD generation, use only the hard gates needed to prevent unsupported boundary-changing rules. Run the full checklist as an activity-logic validation only when the user explicitly asks to校验/检查/走查活动逻辑. The target remains the user-selected requirement surface: either the `需求模块 / 原型截图 / 需求描述` three-column PRD or the integrated prototype-flow board. This file is not a product-rule source. A listed item means “check whether the current evidence defines this”; it does not authorize adding the item, an example option, an exception, or a fallback to the PRD. For every missing boundary-changing answer, ask the user before writing. After validation, report findings and ask whether to补充 before editing; keep the checklist and review results out of the formal PRD.

## Evidence rule

- Accept product rules only from the user's explicit correction/confirmation, latest PRD, explicit rule document or mind map, or current prototype evidence.
- Apply the user-confirmed standing gift-channel default as the sole exception: gift-scoring activities count `多人房`, `单人房`, `永续房`, IM, and `贴吧` gift sending unless the current source explicitly excludes or changes a channel. Use these exact Chinese channel names in Chinese PRDs.
- Treat all example choices in this reference as question options only. Never select or write one without source evidence or user confirmation.
- Do not create an `异常说明`, `异常/限制`, or `评审检查点` section because an item below is absent.
- When a real exception is explicitly present in the source, write it in the most relevant existing requirement section; create a separate exception heading only when needed for clarity.

## Contents

1. Baseline activity contract
2. Calculation and fallback rules
3. Lifecycle and common UI rules
4. Module-specific checks
5. Acceptance-criteria prompts

## 1. Baseline Activity Contract

Write the confirmed activity-wide baseline outside the page-facing requirement surface. Use an independent `活动对象` section for the general audience, blacklist logic/list/IDs, and global version eligibility. Keep only module-specific eligibility exceptions inside a module row or its corresponding board requirement card. See `activity-prd-document-structure.md` for the canonical document layout.

### 1.1 Participants and identities

Check whether the source separately defines who may view, enter, participate, score, rank, claim, and receive rewards.

Participant modes may include:

- individuals;
- groups: family, agency, or custom group;
- imported UID lists or whitelists;
- all users except blacklisted or non-activity-region users.

When host and viewer status can differ, traverse at least these combinations for entrance, panel visibility/click, page visibility, scoring, and rewards:

| Host | Viewer | Required decision |
|---|---|---|
| eligible | eligible | normal behavior |
| ineligible | eligible | viewer entry and host-side gameplay visibility |
| eligible | ineligible | viewer entry restriction and host page behavior |
| ineligible | ineligible | entrance, page, and interaction behavior |

Check whether the source states whether imported users with zero score appear on a ranking and how cached/out-of-range ranks display.

### 1.2 Time model

For every phase, task, ranking, inventory, buff, and settlement, check whether the source defines:

- start and end timestamp;
- governing time zone;
- reset/refresh time;
- regional time or global time;
- cross-day and daylight-boundary behavior where relevant.

If the source says global time, check which model it means:

1. a single specified time zone, such as GMT+8;
2. a global window from the earliest regional start through the latest regional end.

If some regions can start or end at different times, check whether the source specifies entrance, page, scoring, and reward behavior for the partially active state.

### 1.3 Region, blacklist, and eligibility

For blacklist and non-activity-region users, check whether the source independently defines:

- whether they can see the entrance and activity page;
- whether they can participate, score, rank, advance, or receive rewards;
- whether their gift/task behavior contributes to another eligible user's score;
- the UI state and explanatory copy;
- behavior when status changes during the activity;
- whether previously earned score/rewards are retained, removed, or frozen.

For agency gameplay, also check whether the source defines how agency status, agent country/blacklist status, and each signed host's contract/region/blacklist status affect scoring and rewards. Possible contract states depend on current evidence and may include active, pending renewal, terminated, renewing, and renewed.

### 1.4 Anti-abuse

Treat anti-abuse as a module-level hard gate whenever users can obtain free lottery tickets, free gift packs, claimable benefits, or other zero-cost rewards. Do not draft that module until the source or user confirms the anti-abuse approach. Paid-only paths do not trigger this gate unless a free path also exists.

If missing, ask which controls apply; examples for the question include:

- device limit: maximum participating/claiming accounts per device;
- anti-scalper blacklist;
- malicious-refund blacklist;
- IP limit;
- frequency, daily cap, and retry limit.

Also ask about limits, user-facing behavior, and whether a blocked action consumes an opportunity. Do not supply a default or select controls automatically.

### 1.5 Scoring and source channels

Check whether the source defines:

- scoring actor: sender, receiver, host, viewer, group, CP pair, or agent;
- included gift/task/content IDs and excluded IDs;
- package gifts: free and paid package gifts;
- blind-box gifts: outer gift or revealed prize value;
- rooms/channels included.

Also check whether the activity-level materials identify the activity gifts themselves: configured gift IDs, names/icons where needed, whether each gift contributes through sending or receiving, and how package or blind-box gifts are interpreted.

Unless the current source explicitly excludes or changes a channel, write the standing default into the relevant scoring/data rule: `多人房`, `单人房`, `永续房`, IM, and `贴吧` gift sending are counted for configured activity gifts.

For multi-person rooms, still check host, guest, and viewer send/receive combinations. Confirm whether the statistical subject is the sender or recipient so score is assigned to the correct identity. An explicit current-source channel or role rule overrides the standing default.

### 1.6 Rewards, inventory, and budget

For every reward, check whether the source defines:

- eligibility and threshold;
- fixed amount or calculation formula;
- automatic delivery or manual claim;
- delivery time and recipient identity;
- virtual-reward behavior when the monetary threshold is unmet;
- failure, retry, duplicate prevention, expiration, and record display;
- fallback reward or possible non-winning result;
- regional or global inventory, refresh time, exhaustion behavior;
- regional/product budget or shared/public budget deduction.

Balances and budgets must remain independent across phases unless the source explicitly permits transfer.

### 1.7 Inventory, platform integrations, and activity resources

When inventory exists, check whether the source defines:

- refresh method and cadence, such as every configured number of hours, regional midnight, or a specified region time;
- regional inventory or global shared inventory;
- replenishment source, timing, and ownership;
- exhaustion behavior only when the current source explicitly defines it.

For every activity, resolve four explicit yes/no decisions: å¤é¨æ´»å¨èå¨, activity-progress aggregation, startup page, and home banner. If the current source already says yes or no, treat it as confirmed and do not ask again. If one or more are absent, ask about all unresolved capabilities in one compact round before drafting.

For every confirmed integration, check visibility/audience, lifecycle, data ownership, resource ownership, click destination/default position, and close/return behavior. For å¤é¨æ´»å¨èå¨, additionally confirm which rules remain owned by the activity versus å¤é¨æ´»å¨èå¨. If an integrated surface displays an avatar, confirm whose identity it represents and the avatar data source. Never infer integration behavior from the capability name alone.

Keep confirmed `不接入` answers in the internal evidence map by default. Do not add a generic negative-integration paragraph or `关联能力` section to the formal PRD. Record a non-integration only when a dedicated scope/configuration row exists in the current document or the user explicitly requests it.

## 2. Calculation and Fallback Questions

For score, task target, reward, pool, or distance calculations, check whether the source defines:

- formula and variables;
- source data and time window;
- inclusion/exclusion conditions;
- rounding: nearest, floor, ceiling, hundreds, thousands, or another unit;
- minimum, maximum, and zero handling;
- missing/insufficient-data fallback;
- refresh timing and whether historical values are recalculated.

For matching or target generation, check whether the source defines behavior when no result meets the normal condition. If absent and implementation-changing, ask; do not invent a fallback.

For unequal pool division, ask for an explicit remainder rule when absent. Possible question options include:

- randomly allocate remaining units among eligible recipients;
- leave the remainder undistributed;
- allocate remaining units by ranking order.

Never select one of these options on the user's behalf or copy it into the PRD without confirmation.

## 3. Lifecycle and Common UI Rules

### 3.1 Required lifecycle states

Check whether the source defines page/entrance behavior for relevant states:

- before activity start;
- active;
- some regions/phases started and others not started;
- some regions/phases ended and others active;
- ended but settlement pending;
- ended and settled;
- empty data/zero score;
- ineligible, blacklisted, or non-region;
- loading, request failure, retry, and degraded state.

For multi-level tabs, check default landing, remembered position, deep-link target, unavailable-tab behavior, and priority. Ask about missing implementation-changing decisions; do not create a fallback.

### 3.2 Common profile display

Where avatar and nickname appear, check whether the source defines:

- avatar click destination or disabled behavior;
- live indicator requirement;
- nickname maximum length, truncation, and full-text access;
- default avatar/name for missing data.

### 3.3 Panel/entrance

Check whether the source defines:

- visibility condition and audience;
- host-side and viewer-side location;
- visual state and red-dot/badge behavior;
- click destination and target tab/anchor;
- refresh timing;
- blacklist/region combinations;
- before/during/after behavior.

### 3.4 Triggered messages

For IM, public-screen messages, popups, bubbles, room effects, and SVGA, check whether the source defines:

- trigger condition;
- recipient/audience;
- payload, style, image, and localization ownership;
- click destination;
- frequency control, deduplication, and expiry;
- behavior if the target activity/page is unavailable.

## 4. Module-Specific Checks

### 4.1 Standard leaderboard

Check whether the source defines:

- daily, phase, or total ranking;
- host, user, group, regional, or global dimension;
- participants, time, score source, and reward rule;
- reward trigger, such as completing a task, reaching a rank or threshold, or winning a gameplay result;
- maximum displayed rank;
- zero-score and unranked sticky-row behavior;
- tie-break rule: first-to-score, UID order, random, or another explicit rule;
- out-of-range rank display such as `99+`;
- distance-to-previous formula, including unranked and beyond-display-limit behavior;
- avatar click and list/sticky-row displayed fields;
- refresh frequency, settlement freeze, and late-data correction.

### 4.2 CP leaderboard

In addition to standard ranking checks, check whether the source defines:

- CP binding/unbinding eligibility and timing;
- score ownership before/after binding changes;
- pair identity and display;
- reward recipients and split rule;
- invalid, dissolved, or not-yet-formed pair handling;
- full-page sticky-row perspective: host or viewer;
- which CP pair is shown when one identity relates to multiple pairs;
- half-page sticky-row selection separately for host and viewer perspectives;
- unpaired sticky-row content, score-zero display, and visual style.

### 4.3 Agency leaderboard

In addition to standard ranking checks, check whether the source defines:

- agency and signed-host statuses eligible to participate;
- agent versus host region/blacklist effects;
- aggregation and deduplication across signed hosts;
- sticky-row identity priority: agent or signed host;
- reward recipient and budget source.

### 4.4 Pursuit battle

Check whether the source defines:

- participants, activity time/time zone, and the trigger time for pursuit to begin;
- pursuer and pursued identity/data ownership;
- pursuit and scoring logic;
- matching selection and evidence-backed behavior when no opponent matches;
- reward delivery, budget, messages, and panel behavior;
- pre-start, active, ended, and no-match page states;
- avatar, nickname, score, and confirmed dynamic changes during pursuit.

### 4.5 Elimination tournament leaderboard

For every confirmed stage, check whether the source defines:

- stage name, start/end time, governing time zone, and settlement time;
- participants, grouping, whether forced insertion/late insertion is allowed, and its scope;
- scoring, advancement condition, and treatment of eliminated participants;
- stage-specific gifts or buff rewards when explicitly present;
- reward delivery, budget, messages, and panel behavior;
- not-started, active, settlement-in-progress, and ended page states;
- timeline, rules, leaderboard list, and sticky-row content.

Do not merge stages that have different clocks, grouping, advancement, scoring, or settlement rules.

### 4.6 PK gameplay

First check which PK type the current source confirms. Question categories may include one-way pursuit PK, two-way PK, user PK, family PK, camp PK, group PK, or client-linked PK; never select a type from this list without evidence.

Then check whether the source defines:

- activity time/time zone, participants, start condition, opponent selection, duration, and attempt cap;
- score source and PK result definitions for win, draw, and loss;
- whether one side or both sides perceive the PK and qualify for rewards;
- client-linked data/result ownership when using the client PK capability;
- reward trigger, recipient, delivery, and record ownership;
- before-start, unmet-start-condition, no-match, active-PK, and ended states;
- both sides' avatar, nickname, score, reward preview/result, PK history, winning record, and rules entry when evidenced.

### 4.7 Gift pack gameplay

Check whether the source defines:

- free or paid pack type;
- participants, gameplay time, claim/purchase condition, and operation method;
- claim limits: once per activity, once per day, repeatable daily, or another confirmed rule;
- reward delivery, inventory, and budget ownership;
- anti-abuse for free packs;
- insufficient-balance interaction for paid packs;
- pack display, claim/purchase button, reward record, and gameplay explanation.

Treat the listed limit modes as clarification options only; do not select one without evidence.

Do not draft a free-pack module while anti-abuse is unresolved. A paid-only pack does not require this anti-abuse gate unless it also includes a free claim, free reward path, or zero-cost eligibility route.

### 4.8 Host level task

Check whether the source defines:

- task period: daily reset or once per activity;
- target source: fixed, formula-based, or another source;
- for recent-history targets, exact formula, excluded high/low values, insufficient-data fallback, and cap/floor;
- counted dimensions such as gift value or live duration;
- reward fixed/formula-based and auto-delivery/manual claim;
- progress, completed state, next-level transition, and all-complete state;
- host info, progress bar, reward display, reward record, and rules entry.

### 4.9 Lottery

Check whether the source defines:

- ticket sources: free, gift, paid, watch-time, task, or other;
- single, multi, and draw-all cost and maximum draw-all count;
- shared or separate inventory for single/multi draw;
- draw frequency controls and opportunity reset;
- one or multiple prize pools and pool selection rule;
- regional/global stock, stock refresh, replenishment, concurrency, and sold-out behavior;
- guaranteed reward, empty result, pity/guarantee, and duplicate reward behavior;
- reward delivery, budget, record, pool display, rules, and result modal.

If any lottery-ticket or draw opportunity is free, apply the anti-abuse hard gate before drafting the lottery module. A fully paid draw does not trigger the gate unless it also exposes a free opportunity.

### 4.10 King-of-the-hill gameplay

Check whether the source defines:

- defender and challenger source;
- challenge eligibility and matching;
- scoring window and tie result;
- explicit defense-success and challenge-success standards;
- defense/challenge rewards and repeated-win limits;
- no defender, no challenger, disconnect, timeout, and settlement behavior only when evidenced;
- pre-start, active arena, result, and ended page states;
- defender/challenger avatar, nickname, score, reward display, and rules entry.

### 4.11 Red-packet rain

Check whether the source defines:

- trigger condition and visible audience;
- entry/open rules and attempts per session;
- pool, inventory, fallback reward, and possible empty result;
- concurrency, frequency, timeout, and late-entry behavior;
- animation, open/result modal, reward record, and message trigger.

### 4.12 Buff or multiplier

Check whether the source defines:

- acquisition condition;
- activation trigger;
- exact gameplay/ranking scope;
- host identity or viewer identity effect;
- stacking, priority, cap, and conflict rules;
- duration, cross-day behavior, and expiry;
- display badge, countdown, and expired state;
- whether calculation uses event time, receipt time, or settlement time.

## 5. Acceptance-Criteria Prompts

Use the following classes only for the internal evidence/completeness audit. Do not append them as acceptance criteria or review checks to the PRD unless the user separately requests that deliverable:

1. eligible and ineligible participation;
2. included and excluded scoring sources;
3. sender/receiver/host/viewer identity combinations;
4. exact time-zone boundaries and reset;
5. zero, empty, tie, cap, out-of-range, and remainder cases;
6. reward success, stock exhaustion, failure/retry, and duplicate prevention;
7. pre-start, active, partially active, ended, and settlement-pending UI;
8. blacklist, non-region, and anti-abuse behavior;
9. role-specific entrance/panel visibility and click destinations;
10. refresh, cache, and late-data behavior.
