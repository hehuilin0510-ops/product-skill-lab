# PRD Output Modes

Use this reference to select and preserve the page-facing requirement format. The selected mode changes presentation only; evidence standards, requirement completeness, and confirmation gates remain identical.

## Selection Gate

- Before creating a new requirement detail or materially changing its layout, ask: `这次需求详情用哪种呈现：三列表格，还是原型＋流程箭头＋需求卡的一体画板？`
- If the request is a narrow edit to an existing artifact and the user has not requested a format change, preserve its current mode.
- Do not infer a mode from convenience, file type, or available tooling.
- If the user explicitly requests both, generate both from one evidence map so their rules remain consistent.
- Lock the selected mode for the whole page-facing requirement scope. Do not mix isolated table rows and board cards unless the current document already requires that structure or the user confirms it.

## Mode A: Three-Column PRD

Use the fixed columns `需求模块 / 原型截图 / 需求描述`.

- Use one row per coherent module or flow group; do not create one row merely for every screenshot.
- Put actual, readable prototype crops in `原型截图` when images exist.
- Write complete, developer-readable rules in `需求描述`, using dynamic headings suited to the module rather than a mechanical fixed template.
- Prefer this mode when development and QA need to review requirements row by row inside DOCX or TAPD.
- Preserve unrelated tables and rich-text sections during a scoped update.

## Mode B: Integrated Prototype-Flow Board

Use an editable Pencil board as the primary artifact. Combine formal prototype states, labelled flow arrows, and complete requirement cards.

### Board Structure

- Group related states by user workflow, not by arbitrary image count. Four to nine states per row is a useful density target, not a hard rule.
- Retain every in-scope formal state exactly once unless the same state is intentionally reused as a documented branch origin.
- Label every arrow with the visible operation or business condition, such as `点击奖励预览`, `开启一次`, `钥匙不足`, `关闭并保留筛选`, or `有记录/无记录`.
- Use page and state names in visible prose. Internal state IDs may appear in small image captions for asset traceability, but never as interaction language such as `点击31跳转32`.
- Place each requirement card beside the workflow group it governs. Use multiple cards within a module when separate flows have materially different rules.
- Keep the board compact enough to browse, but never shrink requirement text until it is unreadable or truncate text to meet an arbitrary canvas height.

### Master-Board Policy

- Keep one active master `.pen` for the current formal state-count or requirement baseline.
- Before a material update, archive a recoverable copy; after the update, continue writing to the same master filename.
- Do not create visible `v2/v3/最终版/修正版` boards for routine corrections. Parallel files require an explicit user request.
- When a new formal state changes the state count, create the new baseline master once and keep the former baseline unchanged in history.
- Update the generator/output configuration together with the master file so a later rebuild cannot regress to an older layout.

### Flow And State Relationships

- Draw an arrow only for a confirmed click, return, state transition, or time-triggered change.
- Use identity/time bands or brackets for mutually exclusive views such as `观众视角 / 主播视角`, `活动未开始 / 活动进行中`, and alternative eligibility states.
- Do not draw a sequential arrow merely because two screenshots appear next to each other.
- For a branching flow, use separate routing lanes and one condition label per branch. Cross-image lines are acceptable when their source, condition, and target are unambiguous. Position labels from their measured height and keep every label bounding box at least 10px from the branch line, arrowhead, and image area; fail generation when the collision check does not pass.
- A rotating set is not automatically a fixed sequence. State the set order in the requirement card and draw sequence arrows only when every eligible session follows that order.
- Keep arrow nodes above image nodes. Verify lines, arrowheads, and labels inside Pencil at overview and close zoom. If path arrowheads disappear, replace them with stable native line or rectangle nodes and large text arrow glyphs.
- Keep role and phase bands visually distinct from interaction arrows so the board does not imply that identity or time labels are clickable.

### Text And Component States

- Calculate requirement-card height from rendered content and keep all text editable. Reject clipped or hidden lines.
- Preserve reference component dimensions when the required state is a standalone panel or card. Do not add a full page or live-room background unless that parent surface is required.
- Place non-activity surfaces such as live-room panels and live-room popups after the complete activity-page modules; do not split the activity-page flow.

### Requirement-Card Content

- A board card is a full PRD requirement surface, not a visual annotation or summary note.
- Use dynamic sections such as `玩法说明`, `页面展示`, `计分规则`, `奖励规则`, `状态差异`, `操作反馈`, `交互链路`, `数据统计`, and `发奖规则`; include only sections supported by current evidence.
- Write one executable rule per bullet. Cover normal flow, confirmed special states, actor/data ownership, update behavior, reward or settlement behavior, and complete return paths where applicable.
- For each clickable control, state the visible entry, destination, default state, close/return position, and whether the action changes filters, progress, inventory, records, rewards, or settlement.
- Do not replace confirmed product logic with design implementation details. Omit opacity, blur, color, corner radius, spacing, grid, and similar designer-owned values unless the user explicitly requests a design specification.
- The board must pass the same evidence and completeness audit as the three-column PRD. Choosing a board must never reduce rule depth.

### Deliverables

- Keep the editable `.pen` file as the source artifact.
- Read `pencil-integrated-board-delivery.md` and use the 统一画板交付标准 output standard for every formal full-board export.
- Export a readable full-board image when requested. Respect any user-specified size limit, and verify text clarity at practical viewing zoom before delivery.
- Default to a 11600 px wide production board unless the current project already has another user-approved formal baseline. Treat Pencil's 8192-pixel-capped built-in export as a preview, not the production source.
- For a PNG size limit, preserve the full board width and height and use `scripts/optimize_share_png.py` from the parent Skill. Select the highest palette that meets the target, check actual bytes, and visually inspect the result. Do not shrink the board to claim compliance unless the user explicitly requests a smaller preview.
- A downloadable image is a distribution copy, not the editable source and not a substitute for verifying the `.pen` file.
- Clickable hotspots are optional and must not be implied by arrows alone. Add them only when the user explicitly requests a clickable prototype.

## TAPD Placement

The document-level structure stays unchanged in both modes.

- Keep `六、需求详情` and `● 活动页面与玩法需求`.
- In three-column mode, place the front-end requirement table below that subsection heading.
- When converting to integrated-board mode, replace only that front-end table with the board image or its insertion point.
- Preserve `● 后台配置需求` and its table unless the user explicitly includes backend requirements in the replacement scope.
- Resolve who inserts the board image: `assistant` or `user`.
- If the user inserts it, leave exactly one blank paragraph below `● 活动页面与玩法需求`; do not add a placeholder image or explanatory copy.
- If the assistant inserts it, upload through TAPD and verify the saved source uses `/tfl/captures/...`, not `data:image`.
- Preserve all unrelated images, headings, version records, and tables.

## Mode-Specific Validation

### Three-Column

- The three required column headers exist in the correct order.
- Each in-scope row has a readable screenshot when available and complete requirement text.
- No target screenshot cell is replaced by screenshot advice or a text placeholder.

### Integrated Board

- Every in-scope formal state is present with no accidental duplicates or missing image references.
- Workflow arrows have human-readable operation or condition labels and point to the intended state.
- Requirement cards contain complete, untruncated text and remain readable at a practical board zoom.
- No internal numeric state-to-state instructions or designer-owned implementation parameters appear in user-visible requirements.
- The editable board parses successfully, and any exported image is visually checked rather than accepted by file generation alone.
- Only one active master `.pen` remains in the working root unless parallel versions were explicitly requested.
- Identity bands, time-phase bands, rotating-set membership, and interaction transitions are not represented as the same kind of arrow.
- The recommended share PNG preserves original dimensions, meets the requested actual-byte limit, and remains legible.

### TAPD Readback

- The selected page-facing surface is present exactly once.
- Converting modes does not delete the backend configuration subsection or unrelated content.
- Saved rich text contains no `data:image` source.
