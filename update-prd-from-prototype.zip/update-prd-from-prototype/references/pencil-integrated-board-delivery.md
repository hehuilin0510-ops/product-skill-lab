# Pencil Integrated Board Delivery Standard

Use this reference whenever an integrated Pencil PRD board is exported, compressed, packaged, or regenerated. This is the established unified-board delivery standard.

## Production Source

- The active `.pen` file is the only editable source of truth.
- Save the current Pencil canvas before rendering and read the saved file back from disk.
- The production board image must be rendered from the saved `.pen` node tree and its bundled image dependencies.
- Do not use a manually stitched image, an earlier raster board, a screen capture, or a flattened image node as the production source.
- Do not claim that an image matches Pencil until screenshot nodes, arrows, requirement cards, text, colors, spacing, and ordering come from the same saved master.

This reference applies to a `PRD 一体画板` containing screenshots, arrows, and requirement cards. It does not define the prototype Skill's 8-column `原型状态大画板`.

## Package Layout And Dependency Bundle

Use one current entry: `00_最终交付/请使用_最新交付/最终交付包`.

Keep its top-level order fixed:

1. `01_Pencil源文件与图片依赖`
2. `02_完整高清原图_不限大小`
3. `03_推荐分享_5MB内`
4. `04_备用分享_PNG_5MB内`
5. `05_快速预览`
6. `06_模块高清分图`
7. `07_QA检查图`
8. `README_交付说明.md`

Treat `01_Pencil源文件与图片依赖` as an inseparable bundle. It contains exactly one active `.pen`, its current state-image folder, every `screenshot-site*.png`, and all other files referenced by the `.pen`. Do not rename, move, delete, or split those dependencies independently. Resolve every image URL relative to the bundle and require `Missing dependencies = 0` before handoff.

Do not leave duplicate active `.pen` files, loose dependency images, root-level build outputs, or multiple active “latest” folders. Move superseded material to `00_最终交付/历史备份/<timestamp>` rather than silently deleting it.

## Unified Board Canvas Standard

- Default full-board width: `11600 px`.
- Preserve an existing user-approved project width when it is already the formal baseline; otherwise normalize integrated-board delivery to 11600 px.
- Derive board height from actual rendered content. Use content-hugging height or calculate the lowest content boundary plus the intended bottom padding.
- Large unused bottom or right canvas areas are delivery defects. Remove them before rendering.
- Keep formal prototype screens large enough to remain readable in focused review. Do not compensate for an over-wide board by shrinking every page node.

## Pencil 8192 Export Gate

Pencil Desktop's built-in raster export may cap the longest edge at 8192 pixels.

- Inspect the actual exported dimensions after every Pencil export.
- If a board expected to exceed 8192 px is exported with a longest edge of exactly 8192 px, treat it as capped.
- If selecting 2x or 3x still produces the same 8192 px edge, do not continue changing the multiplier.
- A capped export may be retained as a quick preview only. It must not become the full-resolution PNG or the recommended share image.
- Never resize an 8192 px flattened export upward. Upscaling cannot restore prototype text or screenshot detail.

## Full-Size Rendering

- Render the saved `.pen` node tree at the approved full-board dimensions, following the established unified-board method.
- Resolve every image URL relative to the active `.pen` dependency folder.
- Preserve frame layout, absolute positions, image fit/fill behavior, text styles, requirement-card fills, section bands, arrow lines, arrow labels, and arrow glyphs.
- Use the original state PNG as the image source for each screenshot node. Do not first shrink all states into a combined raster and then enlarge that raster.
- Render text and vector-like nodes at the target scale. Do not rasterize the entire board at a smaller size before the production render.
- Confirm dependency count, unique state-image count, and missing dependency count before export. Missing dependencies must equal zero.

For a readable 5MB logic-board share image, render the top-level modules/workflow sections separately from the saved node tree at the approved scale, wait for all relative image dependencies to load, and then stitch only those already-rendered approved sections in the established board order. Do not compress an 8192px-capped Pencil export or reduce the board dimensions before compression. Keep the lossless full-resolution PNG and module-level high-resolution PNGs alongside the same-dimension 4:4:4 JPEG share copy, and inspect a prototype-dense crop at practical zoom before handoff.

## Required Active Outputs

Use the same fixed unified-board naming pattern:

- `02_完整高清原图_不限大小/02_完整高清原图_不限大小.png`
- `03_推荐分享_5MB内/03_推荐分享_5MB内最清晰原尺寸.jpg`

The lossless PNG keeps the approved full dimensions. The share image must keep exactly the same width and height.

## 5 MB Share Image

- Target a maximum of `4,900,000` bytes to leave filesystem and upload margin.
- Do not reduce width or height to meet the byte limit.
- Try same-dimension optimized PNG first when it can preserve readability.
- When PNG cannot meet the limit cleanly, create a same-dimension JPEG using 4:4:4 chroma sampling (`subsampling=0`), optimized/progressive encoding, and the highest quality that stays below the target.
- Use a quality search rather than selecting an arbitrary low quality. Record the chosen quality, dimensions, and bytes in the delivery readback or README.
- Do not put a file larger than 5 MB inside `03_推荐分享_5MB内`.

For a same-dimension PNG attempt, use the bundled optimizer with the formal byte ceiling:

```bash
python3 scripts/optimize_share_png.py <input.png> <output.png> --target-bytes 4900000
```

If the optimizer reports that the target cannot be met without resizing, keep the full-size lossless PNG and use the same-dimension 4:4:4 JPEG route above. Do not mislabel a failed or oversized PNG as the recommended share file.

## Visual QA

Inspect all of the following before delivery:

- Full-board overview: correct workflow order, section bands, no missing rows, and no large unused canvas.
- At least one original-size crop containing multiple prototype screens and arrows.
- At least one dense requirement-card crop with readable Chinese text.
- Changed or high-risk flows, especially branching arrows, result popups, and shared/public cards.
- Colors against the Pencil canvas, including white board background, gray requirement cards, pink section bands, and blue arrows.

The state screenshots in focused crops must retain readable UI text. If a practical viewer still shows blurred pages, investigate the node size, source-image resolution, renderer scale, or viewer downsampling instead of repeatedly recompressing the same raster.

## Active-Folder Hygiene

- Keep exactly one current production PNG in `02_完整高清原图_不限大小`.
- Keep exactly one recommended current share image in `03_推荐分享_5MB内`.
- Move Pencil-capped 8192 exports, experimental 16400/7100 variants, obsolete layouts, earlier compression attempts, and duplicate `请打开` copies into `00_最终交付/历史备份/<timestamp>`.
- Do not leave an old but similarly named image in the latest package where it can be mistaken for the formal output.
- For Finder handoff, use icon view, arrange by name, and snap items to the grid so the numbered package order is immediately visible. This presentation step does not replace filesystem and dependency validation.

## Final Readback

Before handoff, report and verify:

- active `.pen` path and file size;
- formal state-image count and missing dependency count;
- production PNG dimensions and bytes;
- share-image dimensions, bytes, format, chroma sampling, and quality when applicable;
- active output folders contain only the intended current files;
- the exported board was produced from the saved `.pen`, not a stale renderer snapshot.
