# Recent Lessons

Use this file for non-canonical edge cases and historical failure lessons. Canonical generation, state-construction, and delivery rules live in `image2_generation_guide.md`, `state_generation_rules.md`, and `qa_gate.md`.

## Scope And Semantic Ownership

- Before a subtractive edit, split the target into `field/value`, `visual affordance`, `click action`, `destination state`, and `business logic`. Removing a reward-help `?` normally removes only the icon and its confirmed help state; it does not remove the reward field, pool, ratio, threshold, or settlement rule without separate evidence.
- A small help icon is not proof that an explanation popup exists. Add the destination state only when the requirement or user confirms it.
- Keep leaderboard reward concepts separate: visible reward field, page-level `奖励预览`, row-level help icon, reward popup, and settlement logic.
- A control that is visible somewhere is not necessarily owned by the current module. Place record, reward, filter, and ranking controls only on the confirmed surface.
- Preserve a known board/delivery style when the user asks to continue an existing project; do not redesign the delivery format for convenience.

## High-Risk State Lessons

- Daily rankings may use date switching; total/cumulative rankings must not inherit it automatically.
- Put TOP reward bars inside the relevant TOP row, never over headers, names, avatars, scores, or buttons.
- If one action can produce multiple outcomes, consider separate single-result, batch-result, and combined-result states when the source supports them.
- Reward tables must satisfy the requested presentation, not merely contain the right words. A requested icon/placeholder field is not fulfilled by text-only output.
- Keep currency and virtual rewards in a stable order with enough space for names and quantities.
- Normal modal and lightweight dropdown behavior differ: a dropdown may cover content without a heavy mask, but it still must remain clean and readable.

## Project-State And Recovery Lessons

- After context compression or handoff, rebuild current facts from saved project docs rather than memory. If files conflict, start from `handoff_summary.md` plus the latest user-confirmed `prototype_blueprint.md`, then repair stale documents before generation.
- When a state is cancelled, archive it, remove it from the active state directory and `display_order.md`, keep later numeric filenames stable unless renumbering is requested, update the expected count, and rebuild all current consumers.
- Board builders may emit generic temporary filenames. Before delivery, overwrite the project's fixed recommended names, archive prior fixed outputs, and ensure the final folder contains only the agreed current set.
- After moving state images, verify both HTML relative paths and board inputs. A clean directory with broken references is not a valid handoff.
- If a newer candidate exists only in chat or a temporary result, do not rebuild from the older formal state. Materialize, validate, and promote the candidate first.

## Efficient Review

- Generate high-risk modules in small batches and inspect focused QA before continuing.
- Review fine UI details in state images or focused crops, not only on a long overview board.
- A visually attractive candidate still fails if it deletes retained business fields or moves a control into the wrong module.
- Once a user accepts a visually consistent candidate and business anchors are intact, do not regenerate merely for harmless anti-aliasing or spacing differences.
