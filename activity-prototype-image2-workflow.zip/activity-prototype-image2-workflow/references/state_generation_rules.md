# State Generation Rules

## Numbering And Names

- Use stable two-digit IDs: `01_...png`, `02_...png`.
- Keep filenames descriptive and in the user's language.
- Do not renumber existing confirmed states unless the user explicitly asks.
- Put new states at the end or at the confirmed insertion point in `display_order.md`.

## Display Order

- Order states by gameplay reading flow, not by file creation time.
- Group by module.
- Put explanation, detail, result, exception, and reward pages near the page that triggers them.

## Page Construction

- Main pages establish shared header, tabs, entry cards, counters, and core action area.
- All visible single-state UI must come from image2 generation or image2 source-image reconstruction. Do not use code-rendered pages, HTML/CSS screenshots, canvas/SVG drawings, PIL composition, or patch scripts as state PNGs.
- When any visible or semantic UI changes, regenerate the full affected state PNG with image2 from the latest clean source. Do not paste changed text, icons, buttons, cards, rows, masks, or popup pieces onto an old state image.
- Popups must use the correct base page underneath, not another popup screenshot.
- Popups must use the latest confirmed clean parent page (`干净父页面`), not a screenshot with an old popup, old dropdown, stale mask (`旧蒙层`), old list, or old entry.
- Result popups must make reward slots, quantities, action feedback, and close/OK behavior clear.
- Ranking pages must separate top rows, reward displays, table fields, date/countdown controls, and sticky personal rows without overlap.
- Reward pages must preserve tables and tabs, and remove bottom OK buttons only when project rules say so.
- History popups must use a clean base page and show only the intended scope: personal record, global history, or empty history.

## Popup And Floating-Layer State Rules

- Create separate states for rule explanation popups, reward explanation popups, result popups, record/history popups, confirmation popups, and expanded dropdown/filter layers when they change the user's decision context.
- Popup state names should identify the trigger source and popup type, for example `玩法-获奖记录弹窗`, `榜单-奖励说明弹窗`, or `主播榜-日期选择下拉`.
- Rule and instruction popups should be read-only close-only states: keep the top-right `X`, and do not add a bottom `OK`/confirm button unless the user explicitly asks for a confirmation action.
- Record/history popup prompts must state the display scope: personal record, global history, empty record, selected date record, or other confirmed scope.
- Normal popups keep the exact same mask token (`蒙层一致`) within a project/version. Record the token in `project_rules.md` and `version_rules.md` before generation: mask color, opacity, blur/dim treatment, dialog shadow, close/confirm control style, and source state. If no approved source exists, use one default for the whole version: `#000000` at `55%` opacity, no blur.
- Do not let image2 invent a new mask per popup. If a popup output has a different mask color, opacity, dirty shadow, or blur treatment from the recorded token, reject and regenerate it from the clean parent page.
- Normal popup layer order is parent page background < mask < popup body < close/confirm controls.
- Dropdowns, level filters, date selectors, and filter menus are lightweight floating layers (`下拉浮层`). They may cover ranking rows or content areas, but should not add a heavy modal mask unless explicitly required.
- Regenerate states with black dirty shadows (`黑影`), pasted dropdown edges (`贴片`), white cover blocks, hard masks, ghost text, or old content remnants (`旧内容残留`).

## Result Popup Rules

- Show reward image placeholders and quantities for every material reward.
- Reuse one shared reward placeholder asset within the same project/version. Do not redraw a new reward icon for each popup, reward grid, or board cell unless the user explicitly asks for different reward art.
- Keep currency rewards and virtual rewards visually separate when both are present.
- Include batch-result and combined-result states when the action can complete multiple milestones in one attempt.
- Keep OK/close behavior consistent with project rules and leave spacing between reward grids and buttons.

## Ranking Rules

- Distinguish total/guild rankings from daily rankings before drawing date controls.
- Add date switching only to daily rankings.
- Show countdown values in the required format; cumulative countdowns may need day units.
- Place TOP reward bars only within TOP rows, never over headers, avatars, scores, or operation buttons.
- TOP4 and later rows must not show TOP reward bars unless explicitly requested.
- Use focused QA for ranking pages because overlap issues are common.

## Reward And Rule Page Rules

- Reward explanation entries such as `?` require a corresponding explanation popup state.
- Rules and reward tables should not have compressed text, clipped table borders, or obsolete bottom buttons.
- Rule/instruction popups should not include bottom `OK` buttons by default.
- Do not remove close buttons unless the project rules explicitly require it.

## Header And Banner Rules

- Header prize pools, countdowns, TOP indicators, gifts, and module slogans are module-specific. Do not copy them blindly to every tab.
- Treat header/banner/gift/icon regions as image2-sensitive and avoid script placeholder art.

## Prompts

`prompts.md` must include one entry per state:

```markdown
## 01_filename.png
- Goal:
- Baseline/reference:
- Must show:
- Must not show:
- QA focus:
```

## Visual Constraints

- Do not script-draw any visible state UI. Scripts may validate, organize, stitch already-approved image2 PNGs into boards, and optimize delivery files only.
- Do not use hard masks or pasted blocks to cover old content.
- Do not use partial pasted overlays inside final state PNGs. Pasting is only allowed for board assembly with whole approved state PNGs, labels outside screenshots, preview-only review artifacts, or non-visual optimization.
- Do not crop from a large board as the source for single-state reconstruction.
- Regenerate images with text ghosts, broken Chinese, deformed icons, or layout drift.
- For high-risk pages, generate focused QA images before final delivery.
