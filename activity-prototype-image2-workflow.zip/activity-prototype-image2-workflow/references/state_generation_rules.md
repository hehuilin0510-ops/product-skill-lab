# State Generation Rules

## Numbering And Names

- Use stable two-digit IDs: `01_...png`, `02_...png`.
- Keep filenames descriptive and in the user's language.
- Do not renumber existing confirmed states unless the user explicitly asks.
- Put new states at the end or at the confirmed insertion point in `display_order.md`.
- If an activity gift's formal name is unconfirmed, use `活动礼物A`, `活动礼物B`, and so on consistently in every state and text artifact. Never invent a plausible formal gift name, and never assume a fixed gift count.
- After a formal gift name is confirmed, replace its placeholder in the blueprint, prompts, state-image copy, and handoff text, and reject stale placeholders or former names before delivery.

## Display Order

- Order states by gameplay reading flow, not by file creation time.
- Group by module.
- Put explanation, detail, result, exception, and reward pages near the page that triggers them.

## Page Construction

- Main pages establish shared header, tabs, entry cards, counters, and core action area.
- Follow `image2_generation_guide.md` for the image-tool requirement, full-state/no-patch boundary, localized generation, materialization, recovery, and promotion.
- Popups must use the correct base page underneath, not another popup screenshot.
- Popups must use the latest confirmed clean parent page (`干净父页面`), not a screenshot with an old popup, old dropdown, stale mask (`旧蒙层`), old list, or old entry.
- Result popups must make reward slots, quantities, action feedback, and close/OK behavior clear.
- Ranking pages must separate top rows, reward displays, table fields, date/countdown controls, and sticky personal rows without overlap.
- Reward pages must preserve tables and tabs, and remove bottom OK buttons only when project rules say so.
- History popups must use a clean base page and show only the intended scope: personal record, global history, or empty history.

## Popup And Floating-Layer State Rules

- Create separate states for rule explanation popups, reward explanation popups, result popups, record/history popups, confirmation popups, and expanded dropdown/filter layers when they change the user's decision context.
- Popup state names should identify the trigger source and popup type, for example `玩法-获奖记录弹窗`, `榜单-奖励说明弹窗`, or `主播榜-日期选择下拉`.
- Rule and instruction popups should be read-only close-only states: keep the top-right `X`, and do not add a bottom `OK`/confirm button unless the user explicitly asks for a confirmation action.
- Record/history popup prompts must state the display scope: personal record, global history, empty record, selected date record, or other confirmed scope.
- Normal popups keep the exact same mask token (`蒙层一致`) within a project/version. Record the token in `project_rules.md` and `version_rules.md` before generation: mask color, opacity, blur/dim treatment, dialog shadow, close/confirm control style, and source state. If no approved source exists, use one default for the whole version: `#000000` at `55%` opacity, no blur.
- Do not let image2 invent a new mask per popup. If a popup output has a different mask color, opacity, dirty shadow, or blur treatment from the recorded token, reject and regenerate it from the clean parent page.
- Normal popup layer order is parent page background < mask < popup body < close/confirm controls.
- Dropdowns, level filters, date selectors, and filter menus are lightweight floating layers (`下拉浮层`). They may cover ranking rows or content areas, but should not add a heavy modal mask unless explicitly required.
- Regenerate states with black dirty shadows (`黑影`), pasted dropdown edges (`贴片`), white cover blocks, hard masks, ghost text, or old content remnants (`旧内容残留`).

## Activity Panels

- An activity panel is an independent component board without a live-room background; do not turn it into a full-height page or live-room popup.
- Preserve the confirmed container geometry, corner radius, padding, title area, bottom controls, carousel arrows, swipe indicator, and each state's recorded dimensions. Do not normalize all panels to one size for board alignment.
- Historical reference only: one confirmed family used `52-54 = 325x335`, `55 = 320x335`, `56 = 315x335`, `57 = 320x335`, and `62 = 305x335`. Other projects must use their own recorded dimensions and must not inherit these values.
- Keep mutually exclusive ranking, progress, vault/key, audience/host, and pre-activity fallback states separate unless the current project explicitly combines them. A pre-activity fallback panel is an independent state; once the activity is active, it must not remain visible alongside an active-state panel.
- Hide unavailable blocks instead of leaving blank reserved areas unless the approved reference defines an empty state.
- Buttons such as `送礼`, `去支持`, `去开启`, `去宝库`, or `求支持` appear only in states that own them. Place new states at their actual interaction-flow position, not merely at the end of a board.

## Live-Room Popups

- A live-room popup is generated on the latest confirmed complete clean live-room parent page; it is not an independent panel, detached dialog board, or half-screen sheet.
- Every live-room popup uses a centered white dialog treatment. Do not move it to an edge, recolor the dialog body, or convert it into a sheet, toast, or floating card.
- Preserve the parent header, live/host area, video, chat, gift area, bottom tools, and other established room structure. For one historical reference family, states `58-61` used `750x1624`; other projects must use their own approved full-page dimensions.
- Do not start from a parent already containing a popup, mask, dropdown, or stale overlay. Use the recorded project/version mask token and layer order.
- For a user-marked popup region, retain all content outside that region and preserve confirmed close, return, and destination controls. Do not invent extra buttons, tips, or confirmations.
- Every changed panel or live-room popup requires a complete state output plus a focused QA crop/comparison. QA annotations belong only in review artifacts.

## Result Popup Rules

- Show reward image placeholders and quantities for every material reward.
- Maintain a six-category reward-placeholder manifest for `礼物`, `头像框`, `徽章/勋章`, `金豆/金币`, `积分`, and `通用奖励`.
- Use the matching category asset for each unresolved reward and use `通用奖励` only when the category is unknown. Reuse the same source asset and sizing rule across every popup, reward grid, ranking reward, detail page, and board cell within one category.
- Generate placeholder art with image2 or use user-approved source assets. Do not script-draw or independently redraw a placeholder for each state.
- When formal reward art is confirmed, replace every affected instance and reject stale category placeholders before delivery.
- Keep currency rewards and virtual rewards visually separate when both are present.
- Include batch-result and combined-result states when the action can complete multiple milestones in one attempt.
- Keep OK/close behavior consistent with project rules and leave spacing between reward grids and buttons.

## Ranking Rules

- Distinguish total/guild rankings from daily rankings before drawing date controls.
- Add date switching only to daily rankings.
- Show countdown values in the required format; cumulative countdowns may need day units.
- Place TOP reward bars only within TOP rows, never over headers, avatars, scores, or operation buttons.
- TOP4 and later rows must not show TOP reward bars unless explicitly requested.
- Use focused QA for ranking pages because overlap issues are common.

## Reward And Rule Page Rules

- A visible `?` or help icon is only a possible entry and does not prove that an explanation popup exists. Create the corresponding popup state only when the PRD, an approved prototype, or the user explicitly confirms that destination; otherwise record it as an open confirmation item and do not invent the popup.
- Rules and reward tables should not have compressed text, clipped table borders, or obsolete bottom buttons.
- Rule/instruction popups should not include bottom `OK` buttons by default.
- Do not remove close buttons unless the project rules explicitly require it.

## Header And Banner Rules

- Keep one approved activity-header region at the top of every activity state PNG. Reuse the same activity title, key visual, dimensions, and placement across main tabs, detail pages, rankings, reward pages, and all other activity states.
- Treat the header as a shared region inside every state, not as a separately numbered header-state image.
- Build popup, dropdown, and overlay states from a clean parent page that already contains the complete approved header. The recorded mask or floating layer may dim or partially cover the header, but the header must not be removed, cropped away, shifted, renamed, or independently redrawn.
- Header prize pools, countdowns, TOP indicators, gifts, and module slogans are module-specific. Do not copy them blindly to every tab.
- Treat header/banner/gift/icon regions as image2-sensitive and avoid script placeholder art.

## Prompts

`prompts.md` must include one entry per state:

```markdown
## 01_filename.png
- Goal:
- Baseline/reference:
- Must show:
- Must not show:
- QA focus:
```

## Visual Constraints

- Apply the canonical generation and no-patch rules from `image2_generation_guide.md`; do not restate or weaken them here.
- Regenerate images with text ghosts, broken Chinese, deformed icons, or material layout drift.
- For high-risk pages, generate focused QA images before final delivery.
