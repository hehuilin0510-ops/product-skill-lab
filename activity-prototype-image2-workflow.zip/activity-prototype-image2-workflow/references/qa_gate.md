# QA Gate

Run this gate before delivery. Treat failures as blockers unless the user explicitly accepts the risk.

## Route-Specific Deliverables

- `full_production`: approved single-state PNGs; blueprint, mind map, order, prompts, rule, QA, and handoff documents; HTML; original-size 8-column prototype state board; preview; module boards; and focused QA images.
- `focused_update`: changed full-state PNGs, focused QA, and only the existing board/docs affected by those states.
- `delivery_recovery`: the recovered original-resolution image and validation result. Do not require a board rebuild or full project audit unless recovery reveals a real mismatch.
- A quick new draft must include at least `prototype_blueprint.md`, `mindmap.md`, `display_order.md`, and `handoff_summary.md`.

## Deterministic Checks

- State count matches the expected number.
- State PNG filenames are stable and start with two digits.
- State PNG dimensions match the project standard.
- Every single-state PNG is listed in `prompts.md` with image2 generation intent and baseline/reference. No state should be documented as code-rendered, HTML/CSS-rendered, canvas/SVG-generated, PIL-composed, or script-patched.
- `prompts.md` and rules document full-state image2 regeneration for changed UI. No final state should be documented as a partial pasted/overlaid repair.
- `display_order.md` includes every state PNG exactly once.
- Required artifacts exist: state PNGs, `display_order.md`, `prompts.md`, rules, handoff, HTML, board PNG, preview PNG, and focused QA PNGs.
- `mindmap.md` exists and matches the confirmed module/gameplay structure.
- `prototype_blueprint.md` and `project_rules.md` record the activity-gift name map, shared activity-header source/invariants, and six-category reward-placeholder manifest.
- Forbidden terms and deprecated copy are absent from text artifacts.
- Formal delivery uses exactly the canonical folders: `00_最终交付`, one `01_状态图_<数量>张`, `02_QA检查图`, `03_模块高清图`, `04_素材源图与调试`, `05_历史大画板归档`, and `06_说明文档`. Run `scripts/qa_check.py <version-dir> --check-delivery` for this gate.
- Main delivery files are under `00_最终交付`, not mixed with drafts or historical boards.
- The main big board uses original-size state images in the intended columns. Do not accept thumbnail/compressed boards as the main board.
- For share-ready delivery, the recommended big board must keep the original pixel dimensions and satisfy the requested file-size limit, such as under 5MB or 20MB. Check actual bytes, not only the displayed Finder size.
- HTML image references still resolve after state PNGs are moved into `01_状态图_xx张`.

## Prototype State-Board Delivery

The prototype `原型状态大画板` is a multi-state visual overview, not the PRD Skill's screenshot＋arrow＋requirement-card integrated board.

- Use the original-size 8-column state board as the default main board. Its width should approximately equal eight source-state widths plus established margins and gaps.
- Thumbnail, downscaled, or compressed overview boards are previews only and must not replace the main board.
- Keep the source state PNGs at their approved dimensions when assembling the board. Board assembly may stitch whole approved states and add labels outside screenshots; it must not redraw or patch state UI.
- When a share-size limit is requested, preserve the board's original pixel dimensions and optimize a separate share copy. Check actual bytes rather than Finder's rounded display.
- Provide the fixed preview `00_最终交付/推荐查看_50%高清预览_5M内.jpg`. It must be exactly 50% of the main board's width and height and no larger than `4,900,000` bytes; it remains a preview, not the main board.
- Use the canonical seven folders listed above for every formal delivery. Archive superseded main/share files instead of leaving multiple apparent latest versions.
- Verify the main board visually at overview and focused zoom, confirm every expected state appears once in the right order, and verify the HTML still resolves moved image paths.

## Visual Checks

Inspect focused QA images at real size or high zoom:

- All visible state UI looks image2-generated/source-native. Reject code-drawn, HTML-rendered, canvas/SVG-rendered, PIL-composed, or visibly patched state pages.
- Changed UI regions are rebuilt as part of the state image, not pasted on top. Reject partial overlays for text, icons, buttons, reward cells, ranking rows, popup bodies, masks, dropdowns, or state labels.
- No reward bars, labels, avatars, buttons, or table rows overlap.
- No hard white blocks, pasted masks, ghost text, or patch edges.
- No old popup visible underneath a new popup.
- No black dirty shadow, pasted border, hard mask, old list remnant, or stale popup content.
- No unexpected crop, stretch, compression, or deformed icon.
- Chinese text is readable, not malformed, not garbled, and not rendered as square boxes.
- Every activity state contains the approved top activity-header region. The activity title, key visual, dimensions, and placement remain consistent across tabs, detail pages, rankings, reward pages, and overlay states.
- Activity-gift labels match the confirmed name map. Unconfirmed names use only `活动礼物A/B/...`; confirmed names leave no stale placeholder or former name.
- New entries, buttons, filters, and record links are placed in the correct gameplay module, not merely visible somewhere on the page.
- Layout changes do not squeeze controls into titles, hero art, primary buttons, reward cards, sticky bars, or table headers.
- Tables and lists use the requested display form, not only the requested field names. For example, reward type can require an icon/placeholder instead of text.
- Pages marked as no-regression still match the previous confirmed behavior.

## Popup And Mask Consistency Checks / 弹窗与蒙层一致性检查

- Normal popups use the latest confirmed clean parent page (`干净父页面`) underneath. Do not use a parent image that already contains another popup, old dropdown, stale mask (`旧蒙层`), old list, or old entry.
- The clean parent page retains the complete approved activity header. The popup mask may dim or partially cover it according to the recorded token, but the header is not cropped, removed, shifted, renamed, or redrawn.
- Popup layer order is fixed: parent page background < mask < popup body < close/confirm controls.
- `project_rules.md` and `version_rules.md` must record the popup mask token before generation: color, opacity, blur/dim treatment, dialog shadow, close/confirm control style, and source state. If no approved source exists, the version default is `#000000` at `55%` opacity, no blur.
- Within the same project/version, normal popup masks (`蒙层`) must match that token exactly. A changed color, opacity, blur, dirty shadow, or one-off dim treatment is a blocker.
- Popup titles, close buttons, confirm buttons, table rows, reward images, and quantity labels are not covered, squeezed, clipped, or pushed into unreadable spacing.
- Long popup content uses a clear scrollable content area or visible table/list container. Do not shrink text until it becomes hard to read.
- Result, record, reward explanation, rule, and confirmation popups must be included in focused QA whenever they are changed or newly generated.
- Rule/instruction popups are close-only by default: they should keep the top-right close button and should not show a bottom `OK`/confirm button unless the product interaction explicitly requires confirmation.

## Dropdown Floating-Layer Exception / 下拉浮层例外

- Date dropdowns, level dropdowns, filter menus, and similar lightweight floating layers may cover ranking rows or content areas when expanded.
- Dropdown floating layers should not be treated as normal modal popups: do not add an extra heavy modal mask unless the product explicitly requires it.
- Dropdowns still must look native and clean: no black dirty shadow (`黑影`), hard edge patch, pasted border (`贴片`), white block cover, old text ghost, old list remnant, or stale content underneath (`旧内容残留`).
- Dropdown options must remain readable and selectable, and should not collide with countdowns, titles, tabs, or primary buttons.

## High-Risk Page Checks

- Main gameplay entry areas: new links or record buttons must belong to the relevant module and not be promoted to a global/header shortcut unless the user confirmed that.
- Ranking pages: TOP reward bars do not cover names, scores, avatars, buttons, headers, or sticky rows.
- Ranking timing: daily rankings have date controls only when needed; total/cumulative rankings show the correct countdown format.
- Reward pages: reward tables, tabs, question-mark help entries, OK/close behavior, and rank ranges are correct.
- Result popups: reward image placeholders and quantities are visible, with no text-only reward fallback unless specified.
- Reward placeholder consistency: unresolved rewards use the recorded category asset for `礼物`, `头像框`, `徽章/勋章`, `金豆/金币`, `积分`, or `通用奖励`; the same category reuses the same source asset and size rules across all states. Use `通用奖励` only when the category is unknown, and reject one-off redrawn or stale placeholder icons.
- History/record popups: base page is clean, uses the latest corrected parent page, and no old list, old entry, or old popup content leaks underneath.
- Header/banner pages: prize pool, countdown, TOP indicators, gift module, and slogan appear only in modules where project rules allow them.
- Rule pages: no obsolete bottom notes/buttons, no default bottom `OK` button, clipped tables, or deprecated terms.

## Blocker Failure Patterns

Regenerate or repair before delivery when any of these appear:

- Any single-state prototype PNG or changed UI region was created by code/HTML/CSS/canvas/SVG/PIL instead of image2.
- Any final single-state prototype PNG contains a partial pasted replacement, overlaid repair, or covered old UI instead of image2 full-state regeneration.
- Square-box Chinese, broken fonts, or unreadable copy.
- Visible overlap, squeezed controls, or semantic placement that contradicts the gameplay module.
- White blocks, pasted patches, hard masks, old text ghosts, inconsistent popup masks, or old UI remnants.
- Popup-over-popup, inconsistent popup mask, stale background, black dirty shadow, pasted dropdown, or record/history dialog using the wrong parent state.
- Missing required controls, filters, countdowns, sticky rows, or field display forms.
- Missing, cropped, shifted, renamed, or independently redrawn activity headers; popup states whose clean parent no longer contains the approved header.
- Invented formal activity-gift names, inconsistent gift labels, or stale `活动礼物A/B/...` placeholders after formal names are confirmed.
- Reward placeholders that do not match the six-category manifest, use inconsistent sizes within one category, or remain after formal reward art is confirmed.

## Context Recovery Check

If context was compacted, interrupted, or the agent is unsure, stop before generating more images and re-read `handoff_summary.md`, `prototype_blueprint.md`, `mindmap.md`, `project_rules.md`, `version_rules.md`, `display_order.md`, and `prompts.md`.

## Delivery Rule

Do not deliver only a long board when the change involves fine UI details. Deliver focused QA images for the changed pages.

Before the final reply, show the real changed/recovered single-state image or focused QA image and, when rebuilt, the main prototype state board. A path, receipt, HTML link, or text statement alone is not visible image delivery. If the preview is missing or collapsed, re-materialize or copy the validated file to a simple workspace path and embed that same file; do not regenerate the design.

Final replies should recommend files from `00_最终交付`. Historical boards and QA artifacts can be mentioned only when the user specifically asks for them.
