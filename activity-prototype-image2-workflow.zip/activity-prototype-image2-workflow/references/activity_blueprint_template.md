# Activity Prototype Blueprint Template

Create `prototype_blueprint.md` from this template before generating images.
Create `mindmap.md` at the same time from `mindmap_template.md`.

```markdown
# Prototype Blueprint

## Activity Overview
- Activity name:
- Audience:
- Core gameplay:
- Visual style:
- Reference assets:
- Output folder:
- Expected state count:
- Single-state size:
- Similarity note: high-similarity reconstruction / low-fidelity draft without enough references

## Module Order
1. Module name
2. Module name

## State List
| ID | Filename | Module | Page Type | Purpose | Baseline/Reference | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 01 | 01_module-main.png | Module | Main page | Main gameplay entry | reference image / text draft |  |

## Interaction Flow
- Module A: `01 -> 02 -> 03`
- Module B: `04 -> 05`

## Rules To Confirm
- State count:
- Module order:
- Mind map structure:
- Special reward/ranking/copy rules:
- Forbidden old terms:

## QA Focus
- Key pages:
- Visual risks:
- Copy risks:
```

Do not start batch image generation until the user confirms this blueprint.
