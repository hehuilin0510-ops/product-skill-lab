#!/usr/bin/env python3
"""Materialize an image_gen result from a Codex session JSONL record.

Usage:
  python materialize_imagegen_result.py \
    --session /path/to/rollout.jsonl \
    --image-id ig_... \
    --out /absolute/path/candidate.png

The script deliberately writes only the image-generation result selected by
image id, then validates the PNG signature and dimensions before replacing the
destination atomically. It does not generate, compose, or edit image content.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import struct
import tempfile
from pathlib import Path


def find_result(session: Path, image_id: str) -> str:
    for line in session.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = record.get("payload", {})
        if record.get("type") != "response_item" or payload.get("type") != "image_generation_call":
            continue
        if payload.get("id") == image_id:
            result = payload.get("result")
            if not result:
                raise RuntimeError(f"Image generation result is empty or not flushed yet: {image_id}")
            return result
    raise FileNotFoundError(f"Image generation id not found in session: {image_id}")


def decode_result(value: str) -> bytes:
    if value.startswith("data:") and "," in value:
        value = value.split(",", 1)[1]
    return base64.b64decode(value)


def png_dimensions(data: bytes) -> tuple[int, int]:
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Result is not a PNG")
    if data[12:16] != b"IHDR":
        raise ValueError("PNG IHDR chunk is missing")
    return struct.unpack(">II", data[16:24])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", required=True, type=Path)
    parser.add_argument("--image-id", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    data = decode_result(find_result(args.session, args.image_id))
    width, height = png_dimensions(data)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{args.out.name}.", suffix=".tmp", dir=args.out.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, args.out)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    print(f"saved={args.out}")
    print(f"dimensions={width}x{height}")
    print(f"bytes={len(data)}")


if __name__ == "__main__":
    main()
