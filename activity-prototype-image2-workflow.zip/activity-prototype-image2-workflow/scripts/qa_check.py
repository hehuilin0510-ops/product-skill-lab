#!/usr/bin/env python3
import argparse
import re
import sys
from collections import Counter
from pathlib import Path

from PIL import Image


STATE_RE = re.compile(r"^\d{2}_.+\.png$")
DOC_DIR = "06_说明文档"
FINAL_DIR = "00_最终交付"
QA_DIR = "02_QA检查图"
MODULE_DIR = "03_模块高清图"
ASSET_DIR = "04_素材源图与调试"
ARCHIVE_DIR = "05_历史大画板归档"
BOARD_NAME = "原排版高清大画板_清晰增强.png"
PREVIEW_NAME = "推荐查看_50%高清预览_5M内.jpg"
PREVIEW_MAX_BYTES = 4_900_000
STATE_DIR_RE = re.compile(r"^01_状态图_(\d+)张$")


def split_csv(value):
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def state_dirs(folder):
    dirs = [folder]
    dirs.extend(sorted(p for p in folder.glob("01_状态图*") if p.is_dir()))
    return dirs


def state_pngs(folder):
    found = {}
    for directory in state_dirs(folder):
        for path in sorted(directory.glob("*.png")):
            if STATE_RE.match(path.name):
                found.setdefault(path.name, path)
    return [found[name] for name in sorted(found)]


def doc_path(folder, name):
    for candidate in [folder / name, folder / DOC_DIR / name]:
        if candidate.exists():
            return candidate
    return folder / name


def display_order_names(path):
    if not path.exists():
        return []
    names = re.findall(r"(\d{2}_[^\n`]+?\.png)", path.read_text(encoding="utf-8"))
    return [name.strip() for name in names]


def prompt_names(path):
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="ignore")
    return [name.strip() for name in re.findall(r"^##\s+(\d{2}_[^\n`]+?\.png)\s*$", text, re.M)]


def blueprint_modules(path):
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="ignore")
    modules = []
    for match in re.finditer(r"^\|\s*\d{2}\s*\|\s*[^|]+?\.png\s*\|\s*([^|]+?)\s*\|", text, re.M):
        module = match.group(1).strip()
        if module not in modules:
            modules.append(module)
    return modules


def main():
    parser = argparse.ArgumentParser(description="QA checks for activity prototype image folders.")
    parser.add_argument("version_dir")
    parser.add_argument("--expected-count", type=int)
    parser.add_argument("--forbidden-terms", default="")
    parser.add_argument("--required-files", default="")
    parser.add_argument("--check-prompts", action="store_true")
    parser.add_argument("--check-mindmap", action="store_true")
    parser.add_argument("--check-delivery", action="store_true", help="Validate the canonical formal-delivery folders and preview.")
    args = parser.parse_args()

    folder = Path(args.version_dir).expanduser().resolve()
    errors = []
    warnings = []

    if not folder.exists():
        print(f"ERROR: folder does not exist: {folder}", file=sys.stderr)
        return 2

    states = state_pngs(folder)
    if args.expected_count is not None and len(states) != args.expected_count:
        errors.append(f"state count {len(states)} != expected {args.expected_count}")
    if not states:
        errors.append("no state PNGs found")

    dims = []
    for png in states:
        try:
            with Image.open(png) as im:
                dims.append((png.name, im.size))
        except Exception as exc:
            errors.append(f"cannot read {png.name}: {exc}")

    counts = Counter(size for _, size in dims)
    if len(counts) > 1:
        detail = ", ".join(f"{size}:{count}" for size, count in counts.items())
        errors.append(f"inconsistent state dimensions: {detail}")

    order_path = doc_path(folder, "display_order.md")
    ordered = display_order_names(order_path)
    state_names = [p.name for p in states]
    missing = sorted(set(state_names) - set(ordered))
    extra = sorted(set(ordered) - set(state_names))
    dupes = sorted(name for name, count in Counter(ordered).items() if count > 1)
    if missing:
        errors.append("display_order missing: " + ", ".join(missing))
    if extra:
        errors.append("display_order extra: " + ", ".join(extra))
    if dupes:
        errors.append("display_order duplicates: " + ", ".join(dupes))

    if args.check_prompts:
        prompts_path = doc_path(folder, "prompts.md")
        prompts = prompt_names(prompts_path)
        prompt_missing = sorted(set(state_names) - set(prompts))
        prompt_extra = sorted(set(prompts) - set(state_names))
        prompt_dupes = sorted(name for name, count in Counter(prompts).items() if count > 1)
        if prompt_missing:
            errors.append("prompts missing: " + ", ".join(prompt_missing))
        if prompt_extra:
            errors.append("prompts extra: " + ", ".join(prompt_extra))
        if prompt_dupes:
            errors.append("prompts duplicates: " + ", ".join(prompt_dupes))

    if args.check_mindmap:
        mindmap_path = doc_path(folder, "mindmap.md")
        if not mindmap_path.exists():
            errors.append("mindmap.md missing")
        else:
            mindmap_text = mindmap_path.read_text(encoding="utf-8", errors="ignore")
            missing_modules = [module for module in blueprint_modules(doc_path(folder, "prototype_blueprint.md")) if module not in mindmap_text]
            if missing_modules:
                errors.append("mindmap missing modules: " + ", ".join(missing_modules))

    if args.check_delivery:
        fixed_dirs = [FINAL_DIR, QA_DIR, MODULE_DIR, ASSET_DIR, ARCHIVE_DIR, DOC_DIR]
        for name in fixed_dirs:
            if not (folder / name).is_dir():
                errors.append(f"formal delivery folder missing: {name}")

        named_state_dirs = [
            path for path in folder.iterdir()
            if path.is_dir() and STATE_DIR_RE.fullmatch(path.name)
        ]
        loose_state_dirs = [
            path for path in folder.iterdir()
            if path.is_dir() and path.name.startswith("01_状态图") and not STATE_DIR_RE.fullmatch(path.name)
        ]
        if len(named_state_dirs) != 1:
            errors.append(f"expected exactly one 01_状态图_<数量>张 folder, found {len(named_state_dirs)}")
        if loose_state_dirs:
            errors.append("noncanonical state folders: " + ", ".join(sorted(path.name for path in loose_state_dirs)))
        allowed_root_dirs = set(fixed_dirs) | {path.name for path in named_state_dirs}
        unexpected_root_entries = [
            path.name for path in folder.iterdir()
            if not path.name.startswith(".")
            and not (path.is_dir() and path.name in allowed_root_dirs)
            and not (path.is_file() and path.name == "00_目录说明.md")
        ]
        if unexpected_root_entries:
            errors.append("unexpected formal-delivery root entries: " + ", ".join(sorted(unexpected_root_entries)))
        if len(named_state_dirs) == 1:
            state_dir = named_state_dirs[0]
            declared_count = int(STATE_DIR_RE.fullmatch(state_dir.name).group(1))
            formal_states = sorted(path for path in state_dir.glob("*.png") if STATE_RE.match(path.name))
            if declared_count != len(formal_states):
                errors.append(f"state folder declares {declared_count} but contains {len(formal_states)} state PNGs")
            outside_states = [path for path in folder.glob("*.png") if STATE_RE.match(path.name)]
            for other_dir in folder.glob("01_状态图*"):
                if other_dir.is_dir() and other_dir != state_dir:
                    outside_states.extend(path for path in other_dir.glob("*.png") if STATE_RE.match(path.name))
            if outside_states:
                errors.append("state PNGs exist outside the canonical state folder: " + ", ".join(sorted(str(path.relative_to(folder)) for path in outside_states)))
            if len(formal_states) != len(states):
                errors.append("formal state count does not match discovered unique state names")

        final_dir = folder / FINAL_DIR
        board_path = final_dir / BOARD_NAME
        preview_path = final_dir / PREVIEW_NAME
        if not board_path.is_file():
            errors.append(f"formal main board missing: {FINAL_DIR}/{BOARD_NAME}")
        if not preview_path.is_file():
            errors.append(f"formal preview missing: {FINAL_DIR}/{PREVIEW_NAME}")
        if final_dir.is_dir():
            extra_previews = [
                path.name for path in final_dir.iterdir()
                if path.is_file() and "预览" in path.stem and path.name != PREVIEW_NAME
            ]
            if extra_previews:
                errors.append("superseded preview files remain active: " + ", ".join(sorted(extra_previews)))
        if preview_path.is_file():
            if preview_path.stat().st_size > PREVIEW_MAX_BYTES:
                errors.append(f"formal preview exceeds {PREVIEW_MAX_BYTES} bytes: {preview_path.stat().st_size}")
            try:
                with Image.open(preview_path) as preview:
                    preview_format = preview.format
                    preview_size = preview.size
                if preview_format != "JPEG":
                    errors.append(f"formal preview is {preview_format}, expected JPEG")
                if board_path.is_file():
                    with Image.open(board_path) as board:
                        expected_preview_size = (int(board.width * 0.5), int(board.height * 0.5))
                    if preview_size != expected_preview_size:
                        errors.append(f"formal preview dimensions {preview_size} != 50% board dimensions {expected_preview_size}")
            except Exception as exc:
                errors.append(f"cannot validate formal preview: {exc}")

    for rel in split_csv(args.required_files):
        candidates = [folder / rel]
        if "/" not in rel and rel in {"prototype_blueprint.md", "mindmap.md", "display_order.md", "prompts.md", "global_rules.md", "project_rules.md", "version_rules.md", "qa_gate.md", "handoff_summary.md"}:
            candidates.append(doc_path(folder, rel))
        if not any(path.exists() for path in candidates):
            errors.append(f"required file missing: {rel}")

    text_files = [
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in {".md", ".html", ".txt"}
    ]
    docs_dir = folder / DOC_DIR
    if docs_dir.exists():
        text_files.extend(
            p for p in docs_dir.iterdir()
            if p.is_file() and p.suffix.lower() in {".md", ".html", ".txt"}
        )
    for term in split_csv(args.forbidden_terms):
        hits = []
        for path in text_files:
            try:
                if term in path.read_text(encoding="utf-8", errors="ignore"):
                    hits.append(path.name)
            except Exception:
                warnings.append(f"skipped text scan: {path.name}")
        if hits:
            errors.append(f"forbidden term {term!r} found in: {', '.join(hits)}")

    print(f"Folder: {folder}")
    print(f"State PNGs: {len(states)}")
    if dims:
        print("Dimensions: " + ", ".join(f"{size} x{count}" for size, count in counts.items()))
    print(f"Display order entries: {len(ordered)}")
    if args.check_prompts:
        print(f"Prompt entries: {len(prompt_names(doc_path(folder, 'prompts.md')))}")
    if args.check_mindmap:
        print("Mind map: " + ("present" if doc_path(folder, "mindmap.md").exists() else "missing"))
    if args.check_delivery:
        print("Formal delivery: checked")
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")
    if errors:
        print("FAILED:")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
