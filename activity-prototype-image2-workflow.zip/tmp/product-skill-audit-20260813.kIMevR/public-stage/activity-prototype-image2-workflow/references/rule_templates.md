# Rule File Templates

Copy these files into each new version folder and fill them before generation.

## global_rules.md

```markdown
# Global Rules

- Use image2 for every single-state prototype PNG and changed UI region.
- Source-image-native reconstruction means image2 with a confirmed source image as baseline; it does not mean code drawing.
- Do not deliver code-rendered, HTML/CSS-rendered, canvas/SVG-generated, PIL-composed, or script-patched state PNGs.
- Do not use white blocks, pasted patches, or script-painted covers to hide old content.
- If visible UI changes, regenerate the full affected state PNG with image2. Do not paste partial replacements inside final state screenshots.
- Pasting/composition is allowed only for whole approved state PNGs in boards, labels outside screenshots, review-only QA callouts, or non-visual optimization.
- Scripts may only organize, check, stitch already-approved image2 PNGs, summarize, optimize delivery files, or generate QA boards.
- Preserve confirmed single-state PNG content unless the current version rules explicitly change it.
- Generate QA images before delivery and inspect them before responding.
- Prefer focused QA images over asking the user to inspect a very long board.
```

## project_rules.md

```markdown
# Project Rules

## Stable Baseline
- Project name:
- Latest confirmed source folder:
- Expected state count:
- Standard single-state size:
- Module order:
- Mind map file: `mindmap.md`

## Stable Logic
- Module/page rules:
- Reward/copy rules:
- Header/banner rules:
- Ranking/list rules:
- Popup rules:
- Popup mask token: color `#000000`, opacity `55%`, blur `none`, dialog shadow/control style copied from source state: TBD. Replace this token only when the user or approved source establishes a different project style.

## Forbidden Terms
- Old term 1
- Old term 2

## Confirmed No-Regression Items
- Item 1
- Item 2
```

## version_rules.md

```markdown
# Version Rules

## Source And Output
- Source folder:
- Output folder:

## This Round Changes
- Changed pages:
- New pages:
- Removed pages:
- Expected state count:

## Do Not Change
- Page or module:
- Confirmed behavior:

## QA Focus
- QA image groups:
- Terms to scan:
- Visual risks:
- Popup mask token for this version:
- Image2-only check: all state PNGs must be image2-generated, not code-rendered or script-composed.
- Patch boundary: changed UI must be full-state image2 regeneration; no partial pasted repairs inside final state PNGs.
```

## qa_gate.md

```markdown
# QA Gate

- [ ] State PNG count matches `version_rules.md`.
- [ ] All state PNG dimensions are consistent unless explicitly allowed.
- [ ] `display_order.md` covers all state PNGs exactly once.
- [ ] `mindmap.md` exists and matches the confirmed module/gameplay structure.
- [ ] Required output files exist.
- [ ] Forbidden terms do not appear in rule/prompts/order files.
- [ ] All state PNGs were generated with image2; no code-rendered, HTML/CSS-rendered, canvas/SVG-generated, PIL-composed, or script-patched state PNGs are delivered.
- [ ] Changed UI regions were regenerated as full image2 state PNGs; no partial pasted/overlaid repairs are present inside final state screenshots.
- [ ] Normal popup masks match the recorded project/version mask token.
- [ ] Focused QA images exist and were inspected.
- [ ] No obvious crop, stretch, overlay patch, text collision, or popup-over-popup issue is visible.
- [ ] `handoff_summary.md` is updated.
```
