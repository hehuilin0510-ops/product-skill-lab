# Axure Activity Visual And State Patterns

Read this reference when reconstructing or extending an Axure activity prototype containing staged rankings, live-room panels, agent/host/user identities, draws, invitation flows, or regional/global states. For guild/agent competitions and multi-stage ranking activities, this is the priority reference for state coverage, board organization, ranking components, and live-room composition.

## Priority Trigger And Source Intake

Use this reference first when the source contains guild/agent competition, multiple ranking stages, regional/global tabs, live-room activity panels, invitation/assistance, or draws.

When the source is an Axure `.rp` file:

- inspect page/state labels and interaction/business copy;
- inventory embedded visual assets by role and dimensions;
- identify repeated components such as ranking rows, crowns, medals, Buff icons, issued stamps, avatars, and live-room parents;
- separate real parent screenshots from overlay components;
- keep uncertain extracted fragments as review notes rather than drawing unsupported UI.

This analysis remains inside the existing image2 workflow; do not create a separate Axure-analysis skill.

## Board Architecture

Organize the board by business module and state cluster rather than by a flat file list. Keep related states adjacent:

- main page, rules, and return path;
- active ranking, future/Coming Soon, history, eliminated, and ended;
- default ranking, timed Buff, assistance, and TOP special states;
- invitation empty, search result, sent, received, accepted, expired, and failure Toast states;
- draw main page, single result, batch result, records, and empty records;
- activity panel, corresponding half-screen, live-room dialog, bubble, and message entry.

Use labels outside state screenshots to identify the business condition that produced each state.

### Mandatory state-cluster matrix

Before image generation, record coverage for each applicable module:

| Module | Active | Future/Coming Soon | History | Eliminated/ended | Empty/unranked | Blocking Toast | Success/result | Identity variants |
|---|---|---|---|---|---|---|---|---|

Do not treat a single active page as complete coverage. Mark states as `not applicable` only when the requirement explicitly excludes them.

## Visual Language

- Base: white canvas, light-gray grouping, black/gray type, restrained borders.
- Semantic accents only:
  - gold for crowns, rank medals, currency, and reward emphasis;
  - orange for streak, boost, or sprint states;
  - blue for confirmed, completed, issued, or selected states.
- Avoid large decorative color fields. Color should identify meaning or status.
- Keep real or representative live-room screenshots as the clean parent for panels, bubbles, and overlays so obstruction and hierarchy can be reviewed.

## Stable Components

### Ranking row

Reserve stable positions for:

- rank/medal;
- avatar and name;
- score;
- reward strip;
- special state: Live, assistance, Buff, advanced, WIN, or issued.

Long reward content should scroll or cycle inside the reward region. It must not compress avatar, name, score, or action controls.

### Sticky personal row

Define variants for ranked, unranked, outside displayed capacity, and context-owned data such as current host vs logged-in user. Do not hide the sticky row only because the score is zero unless the requirement says so.

### Conditional help icon

Do not draw a `?` as a permanent decoration. Tie it to an explicit condition and confirmed popup. A cap explanation icon, page-level reward-preview control, and reward field are separate visual objects.

## State Coverage

For complex actions, include success and failure states:

- future-stage disabled Toast;
- history selected;
- no data/unranked;
- invitation limit, expired, already assisted, or target unavailable;
- manual claim available/claimed;
- automatic reward result;
- network error and retry;
- viewer-region and host-region modules opened at different times.

## Live-Room Overlay Gate

When generating a live-room activity panel or notification:

1. start from a complete clean live-room parent image;
2. preserve host header, public chat, gift entry, and bottom tools;
3. place the overlay in the confirmed interaction zone;
4. verify the overlay can lead naturally to the target half-screen or gift panel;
5. create separate states for user, host, signed host, and agent when the visible panels differ.

Do not generate an isolated card and assume it will fit the live-room context.

## Focused QA

- compare active, future, and historical ranking states together;
- compare identity-owned panels together;
- compare default and conditional-help ranking rows together;
- compare invitation success and every blocking Toast together;
- inspect overlays on the full live-room parent, not only cropped cards;
- verify semantic accent colors remain consistent across repeated icons and states.

## Knowledge Boundary

- Reuse state clustering, stable component geometry, semantic accent colors, full-parent overlay composition, and focused-QA groupings.
- Do not copy source-specific dates, thresholds, advancement counts, reward amounts, caps, or message frequency into a new prototype.
- Use the current activity's requirements and placeholders for all configurable values.
- Activities outside the matching guild/agent or multi-stage ranking pattern may use these patterns selectively; do not force all activities into the same board structure.
