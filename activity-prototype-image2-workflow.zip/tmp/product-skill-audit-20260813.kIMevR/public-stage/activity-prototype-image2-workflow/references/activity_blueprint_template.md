# Activity Prototype Blueprint Template

Create `prototype_blueprint.md` from this template before generating images.
Create `mindmap.md` at the same time from `mindmap_template.md`.

```markdown
# Prototype Blueprint

## Activity Overview
- Activity name:
- Shared activity header source/reference:
- Audience:
- Core gameplay:
- Visual style:
- Reference assets:
- Output folder:
- Expected state count:
- Single-state size:
- Similarity note: high-similarity reconstruction / low-fidelity draft without enough references

## Activity Gift Name Map
| Gift slot | Confirmed formal name | Prototype label | Source/status |
| --- | --- | --- | --- |
| A |  | 活动礼物A | unconfirmed / confirmed source |

- Use `活动礼物A`, `活动礼物B`, and so on while formal names are unconfirmed.
- Keep the number of gift slots equal to the current evidence; do not assume there are two gifts.
- After confirmation, replace the placeholder in the blueprint, prompts, state-image copy, and handoff text, and list the old placeholder/name under forbidden terms.

## Shared Activity Header
- Source/reference:
- Activity title shown:
- Key visual:
- Dimensions and placement:
- Required states: every activity state PNG
- Popup/floating-layer behavior: inherit the complete header from the clean parent page; allow only the recorded mask/layer treatment
- Invariants: do not rename, redraw, resize, shift, crop away, or create a standalone header state

## Reward Placeholder Asset Manifest
| Category | Source asset | Size/placement rule | Status |
| --- | --- | --- | --- |
| 礼物 |  |  | placeholder / formal |
| 头像框 |  |  | placeholder / formal |
| 徽章/勋章 |  |  | placeholder / formal |
| 金豆/金币 |  |  | placeholder / formal |
| 积分 |  |  | placeholder / formal |
| 通用奖励 |  |  | placeholder / formal |

- Use the matching category asset for each unresolved reward; use `通用奖励` only when the category is unknown.
- Reuse the same source asset and sizing rule everywhere within one category.
- Generate placeholder art with image2 or use a user-approved source asset; never script-draw it.

## Module Order
1. Module name
2. Module name

## State List
| ID | Filename | Module | Page Type | Purpose | Baseline/Reference | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| 01 | 01_module-main.png | Module | Main page | Main gameplay entry | reference image / text draft |  |

## Interaction Flow
- Module A: `01 -> 02 -> 03`
- Module B: `04 -> 05`

## Rules To Confirm
- State count:
- Module order:
- Mind map structure:
- Special reward/ranking/copy rules:
- Activity gift name map:
- Shared activity header source/invariants:
- Reward placeholder categories and assets:
- Forbidden old terms:

## QA Focus
- Key pages:
- Visual risks:
- Copy risks:
```

Do not start batch image generation until the user confirms this blueprint.
