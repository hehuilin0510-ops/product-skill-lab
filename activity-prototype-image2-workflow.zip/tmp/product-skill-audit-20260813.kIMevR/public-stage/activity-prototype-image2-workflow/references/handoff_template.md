# handoff_summary.md Template

Use this template in every version folder so another agent can resume after context compression.

```markdown
# Handoff Summary

## Current Version
- Source folder:
- Output folder:
- Current state count:
- Standard state size:
- Last updated:

## Latest User Confirmations
- Confirmation 1:
- Confirmation 2:

## Stable Rules
- See `mindmap.md`.
- Module order:
- Header/banner rules:
- Reward/copy rules:
- Ranking/list rules:
- Popup/result rules:

## This Version Changed
- Changed pages:
- New pages:
- Removed pages:
- Generated outputs:

## Do Not Regress
- Item 1:
- Item 2:

## Known Risks / Needs Review
- Risk 1:
- Risk 2:

## Resume Steps
1. Read `project_rules.md`.
2. Read `mindmap.md`.
3. Read `version_rules.md`.
4. Run `scripts/qa_check.py` from the skill.
5. Inspect focused QA images before continuing.
```
