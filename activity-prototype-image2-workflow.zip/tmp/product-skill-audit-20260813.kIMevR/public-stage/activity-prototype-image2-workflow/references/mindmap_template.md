# Mind Map Template

Create `mindmap.md` together with `prototype_blueprint.md`. Use it to help the user confirm gameplay structure before image generation.

The user may provide `mindmap.md` directly. When provided, treat it as the primary gameplay-structure source, reconcile it with the activity plan, and derive `prototype_blueprint.md` from both. If no mind map is provided, generate a draft with this template and ask the user to confirm it.

```markdown
# Activity Mind Map

## Activity Name

- Activity overview
  - Core goal
  - Main user action
  - Main rewards
  - Settlement / ranking logic

- Module 1
  - Main page
  - Rules / explanation
  - Detail pages
  - Result popups
  - Exception states
  - Rewards

- Module 2
  - Main page
  - Rules / explanation
  - Detail pages
  - Result popups
  - Exception states
  - Rewards

- Global pages
  - Activity rules
  - Reward preview
  - Ranking rewards
  - History records

- QA focus
  - High-risk states
  - Copy terms to verify
  - Reward/ranking logic to verify
```

Do not use Mermaid unless the user explicitly asks. Prefer plain Markdown tree structure because it is easy to review and survives context compression.
