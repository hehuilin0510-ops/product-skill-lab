# Page Taxonomy

Use this checklist to avoid missing states when deriving a complete activity prototype from a plan.

## Core Pages

- Activity landing / main gameplay page
- Module tab main pages
- Rules / instructions popup
- Reward preview / reward detail page
- Detail popup for map node, card, gift, item, or ranking entry
- Result popup for single action
- Batch result popup for 10x, 100x, or multi-action outcomes
- Combined result popup when one action batch completes more than one meaningful outcome
- Insufficient currency / no chance / no permission state
- Unlock / completion / transition prompt
- History / record popup when users need to audit prior results
- Personal record popup when users only need to see their own history

## Ranking Pages

- Ranking main page
- Sub-tabs such as guild/user/host/team/region/total
- Daily ranking date switch when the ranking is daily
- Total ranking countdown when the ranking is cumulative
- Guild/total ranking without date switch when the ranking is not daily
- My rank sticky or empty/no-join state, only where product logic requires it
- No-sticky state when product logic says unjoined/empty personal info should not show a bottom bar
- Top reward explanation popup when reward distribution needs explanation
- Reward question-mark help popup for rank or pool reward labels
- Ranking reward preview pages

## Reward Pages

- Pool list / prize pool popup
- Reward rule / distribution explanation
- Gold/currency reward distribution explanation
- Stage reward / progress reward
- Fallback or guaranteed reward, named according to project rules
- Virtual reward + currency reward display when both exist

## Exception States

- Not joined / no team / no guild
- Not enough points/currency/item
- No attempts left
- Not eligible
- Empty list / no records
- Loading state only if the prototype needs it

## Confirmation Rule

If a page affects user understanding of rewards, ranking settlement, eligibility, or action outcome, include it in the blueprint or explicitly mark it out of scope.

## High-Risk Review Rule

Always mark ranking, reward, result popup, history popup, header/banner, and rule-table pages as QA focus pages in `prototype_blueprint.md`.
