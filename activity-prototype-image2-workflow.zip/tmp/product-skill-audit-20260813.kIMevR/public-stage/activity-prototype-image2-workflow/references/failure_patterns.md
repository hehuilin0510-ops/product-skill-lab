# Failure Patterns

## Patch Or Mask Artifacts

Symptom: white block, hard-edged cover, pasted text strip, old text ghost.

Fix: discard the image and regenerate with image2/source-native reconstruction. Do not cover the artifact with another script layer.

## Partial Pasted UI Repair

Symptom: a changed label, icon, reward cell, button, ranking row, popup body, mask, or dropdown was pasted over the old state image. The result may look close at a glance but has mismatched edges, shadows, font rendering, spacing, or stale content underneath.

Fix: discard the patched state and regenerate the full affected single-state PNG with image2 from the latest clean baseline. Pasting is acceptable only for whole approved state PNGs placed into boards, labels outside screenshots, or review-only QA callouts outside the final state set.

## Board-Crop Reconstruction

Symptom: a single state was cropped from a big board and looks blurry or misaligned.

Fix: rebuild from the single-state PNG or master/source image. Use boards only for review, not as source for detailed redraw.

## Popup-Over-Popup

Symptom: a new dialog is placed over a screenshot that already contains a dialog.

Fix: use the base page without a popup, apply a fresh overlay, and then draw the dialog.

## Context Compression Drift

Symptom: previous decisions vanish, old wording returns, or state count/order regresses.

Fix: stop and read `handoff_summary.md`, `prototype_blueprint.md`, `mindmap.md`, `project_rules.md`, `version_rules.md`, `display_order.md`, and `prompts.md` before continuing.

## Overlong Board Blur

Symptom: the user opens a huge board and says it is blurry even when source states are full-size.

Fix: also produce focused module boards and QA images. Do not rely on a single giant image for detailed review.

## Script-Drawn UI Degradation

Symptom: generated pages look rougher than previous image2 pages, especially icons, gift modules, banners, or complex ranking cards.

Fix: discard the state and regenerate with image2 or image2 using original source assets as the baseline. Scripts may stitch and verify, not visually redesign the UI.

## Code-Rendered State PNG

Symptom: a state PNG was created from HTML/CSS, canvas/SVG, PIL composition, screenshot automation, or another code path instead of image2.

Fix: reject it even if the layout looks clean. Use the code output only as a private layout reference if helpful, then regenerate the actual state PNG with image2. Do not deliver code-rendered state PNGs.

## Inconsistent Popup Mask

Symptom: popup masks differ across states, such as different dark overlay color, opacity, blur, or dirty shadow.

Fix: define or recover the project mask token from the latest approved popup. Regenerate affected popup states from the clean parent page using the exact same token. If no approved popup exists, use one default for the whole version: `#000000` at `55%` opacity, no blur.

## Ranking Logic Drift

Symptom: date switching appears on a total/guild ranking, or countdown copy/format does not match the ranking type.

Fix: classify the ranking as daily, total, guild, user, host, or faction before generation. Put the rule in `project_rules.md` and QA the focused ranking board.

## Missing Reward Explanation

Symptom: a `?` help entry appears after a reward label but no explanation popup state exists.

Fix: add a shared reward-explanation popup state to the blueprint and display order.

## Missing Personal History Scope

Symptom: a history popup shows global pool summaries when the product only needs the current user's record.

Fix: define history scope in the blueprint: personal, global, empty, or mixed. Generate only the required scope.
