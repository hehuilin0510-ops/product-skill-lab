#!/usr/bin/env python3
import argparse
import re
from datetime import datetime
from pathlib import Path


TABLE_ROW_RE = re.compile(r"^\|\s*(\d{2})\s*\|\s*([^|]+?\.png)\s*\|\s*([^|]+?)\s*\|", re.M)


GLOBAL_RULES = """# Global Rules

- Use image2 for every single-state prototype PNG and changed UI region.
- Source-image-native reconstruction means image2 with a confirmed source image as baseline; it does not mean code drawing.
- Do not deliver code-rendered, HTML/CSS-rendered, canvas/SVG-generated, PIL-composed, or script-patched state PNGs.
- Do not use white blocks, pasted patches, or script-painted covers to hide old content.
- If visible UI changes, regenerate the full affected state PNG with image2. Do not paste partial replacements inside final state screenshots.
- Pasting/composition is allowed only for whole approved state PNGs in boards, labels outside screenshots, review-only QA callouts, or non-visual optimization.
- Scripts may only initialize documents, organize, check, stitch already-approved image2 PNGs, summarize, optimize delivery files, or generate QA boards.
- Preserve confirmed single-state PNG content unless version rules explicitly change it.
- Generate and inspect focused QA images before delivery.
- Do not rely on a single huge board for fine-detail review.
"""


QA_GATE = """# QA Gate

- [ ] State PNG count matches `prototype_blueprint.md` and `version_rules.md`.
- [ ] All state PNG dimensions are consistent unless explicitly allowed.
- [ ] `display_order.md` covers all state PNGs exactly once.
- [ ] `prompts.md` covers every state.
- [ ] Required output files exist.
- [ ] Forbidden terms do not appear in text artifacts.
- [ ] All state PNGs were generated with image2; no code-rendered, HTML/CSS-rendered, canvas/SVG-generated, PIL-composed, or script-patched state PNGs are delivered.
- [ ] Changed UI regions were regenerated as full image2 state PNGs; no partial pasted/overlaid repairs are present inside final state screenshots.
- [ ] Normal popup masks match the recorded project/version mask token.
- [ ] Focused QA images exist and were inspected.
- [ ] No crop, stretch, overlay patch, text collision, popup-over-popup, or script-drawn degradation is visible.
- [ ] `handoff_summary.md` is updated.
"""


def parse_states(blueprint_text):
    states = []
    for match in TABLE_ROW_RE.finditer(blueprint_text):
        state_id = match.group(1).strip()
        filename = match.group(2).strip()
        module = match.group(3).strip()
        states.append((state_id, filename, module))
    return states


def write_if_missing(path, text, force=False):
    if force or not path.exists():
        path.write_text(text, encoding="utf-8")
        return True
    return False


def main():
    parser = argparse.ArgumentParser(description="Initialize docs for a full activity prototype image2 project from prototype_blueprint.md.")
    parser.add_argument("version_dir")
    parser.add_argument("--blueprint", default="prototype_blueprint.md")
    parser.add_argument("--project-name", required=True)
    parser.add_argument("--baseline", default="new activity brief")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    folder = Path(args.version_dir).expanduser().resolve()
    folder.mkdir(parents=True, exist_ok=True)
    blueprint_path = Path(args.blueprint)
    if not blueprint_path.is_absolute():
        blueprint_path = folder / blueprint_path
    if not blueprint_path.exists():
        raise SystemExit(f"blueprint not found: {blueprint_path}")

    blueprint_text = blueprint_path.read_text(encoding="utf-8")
    states = parse_states(blueprint_text)
    if not states:
        raise SystemExit("no states found in blueprint table. Expected rows like: | 01 | 01_name.png | Module | ... |")

    modules = []
    for _, _, module in states:
        if module not in modules:
            modules.append(module)

    order_lines = ["# Display Order", ""]
    counter = 1
    for module in modules:
        order_lines.extend([f"## {module}"])
        for _, filename, state_module in states:
            if state_module == module:
                order_lines.append(f"{counter:02d}. {filename}")
                counter += 1
        order_lines.append("")

    prompt_lines = ["# Prompts", ""]
    for state_id, filename, module in states:
        prompt_lines.extend([
            f"## {filename}",
            f"- Module: {module}",
            "- Goal:",
            "- Baseline/reference:",
            "- Must show:",
            "- Must not show:",
            "- QA focus:",
            "",
        ])

    mindmap_lines = [f"# {args.project_name} Activity Mind Map", ""]
    mindmap_lines.extend([
        "- Activity overview",
        f"  - Source/baseline: {args.baseline}",
        f"  - Expected state count: {len(states)}",
        "  - Core gameplay: fill from confirmed `prototype_blueprint.md`",
        "  - Main rewards: fill from confirmed `prototype_blueprint.md`",
        "",
    ])
    for module in modules:
        mindmap_lines.append(f"- {module}")
        for state_id, filename, state_module in states:
            if state_module == module:
                mindmap_lines.append(f"  - {state_id} {filename}")
        mindmap_lines.append("")
    mindmap_lines.extend([
        "- Global QA focus",
        "  - Missing states",
        "  - Reward and ranking logic",
        "  - Popup/result/exception coverage",
        "  - Forbidden old terms",
        "",
    ])

    project_rules = f"""# Project Rules

## Stable Baseline
- Project name: {args.project_name}
- Source/baseline: {args.baseline}
- Expected state count: {len(states)}
- Module order: {' -> '.join(modules)}

## Stable Logic
- Fill from confirmed `prototype_blueprint.md`.
- Popup mask token: color `#000000`, opacity `55%`, blur `none`, dialog shadow/control style copied from source state: TBD. Replace this token only when the user or approved source establishes a different project style.

## Forbidden Terms
- Fill deprecated words and old gameplay terms before generation.

## Confirmed No-Regression Items
- Fill after each user confirmation.
"""

    version_rules = f"""# Version Rules

## Source And Output
- Source folder: {args.baseline}
- Output folder: {folder}

## This Round
- Generate complete low-fidelity activity prototype from confirmed `prototype_blueprint.md`.
- Expected state count: {len(states)}

## Do Not Change
- Do not change the confirmed blueprint without user approval.
- Do not script-draw, code-render, HTML/CSS-render, canvas/SVG-generate, PIL-compose, or patch any visible state UI.
- Do not paste partial UI repairs inside final state PNGs. Regenerate the full affected state with image2 when visible UI changes.

## QA Focus
- Generate focused QA images for complex modules, ranking pages, reward pages, and result popups.
- Popup mask token for this version: use `project_rules.md` token unless user confirms a change.
- Image2-only check: all state PNGs must be image2-generated, not code-rendered or script-composed.
- Patch boundary: changed UI must be full-state image2 regeneration; no partial pasted repairs inside final state PNGs.
"""

    handoff = f"""# Handoff Summary

## Current Version
- Source folder: {args.baseline}
- Output folder: {folder}
- Current state count: {len(states)}
- Standard state size: fill after first generated PNG
- Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Latest User Confirmations
- Blueprint confirmed before image generation: fill confirmation note.

## Stable Rules
- See `prototype_blueprint.md`.
- See `mindmap.md`.
- See `project_rules.md`.

## This Version Changed
- Complete prototype generation initialized from activity brief.

## Do Not Regress
- Keep confirmed blueprint, module order, filenames, and state count unless user changes them.

## Resume Steps
1. Read `prototype_blueprint.md`.
2. Read `mindmap.md`.
3. Read `project_rules.md`.
4. Read `version_rules.md`.
5. Run QA checks after image generation.
6. Inspect focused QA images before delivery.
"""

    outputs = {
        "mindmap.md": "\n".join(mindmap_lines).rstrip() + "\n",
        "display_order.md": "\n".join(order_lines).rstrip() + "\n",
        "prompts.md": "\n".join(prompt_lines).rstrip() + "\n",
        "global_rules.md": GLOBAL_RULES,
        "project_rules.md": project_rules,
        "version_rules.md": version_rules,
        "qa_gate.md": QA_GATE,
        "handoff_summary.md": handoff,
    }

    written = []
    skipped = []
    for name, text in outputs.items():
        path = folder / name
        if write_if_missing(path, text, args.force):
            written.append(name)
        else:
            skipped.append(name)

    print(f"Project: {args.project_name}")
    print(f"States: {len(states)}")
    print(f"Modules: {', '.join(modules)}")
    if written:
        print("Written: " + ", ".join(written))
    if skipped:
        print("Skipped existing: " + ", ".join(skipped))


if __name__ == "__main__":
    main()
