#!/usr/bin/env python3
import argparse
from datetime import datetime
from pathlib import Path

from PIL import Image


def state_pngs(folder):
    return sorted(p for p in folder.glob("[0-9][0-9]_*.png"))


def main():
    parser = argparse.ArgumentParser(description="Create or refresh handoff_summary.md for an activity prototype folder.")
    parser.add_argument("version_dir")
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--summary", required=True)
    args = parser.parse_args()

    folder = Path(args.version_dir).expanduser().resolve()
    states = state_pngs(folder)
    dims = []
    for path in states:
        try:
            with Image.open(path) as im:
                dims.append(im.size)
        except Exception:
            pass
    dim_text = "unknown"
    if dims:
        common = max(set(dims), key=dims.count)
        dim_text = f"{common[0]} x {common[1]}"

    text = f"""# Handoff Summary

## Current Version
- Source folder: {args.baseline}
- Output folder: {folder}
- Current state count: {len(states)}
- Standard state size: {dim_text}
- Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Latest User Confirmations
- {args.summary}

## Stable Rules
- See `project_rules.md`.
- See `global_rules.md`.

## This Version Changed
- See `version_rules.md`.

## Do Not Regress
- Keep all confirmed no-regression items in `project_rules.md` and `version_rules.md`.

## Known Risks / Needs Review
- Inspect focused QA images before delivery.
- Re-run QA after any image regeneration.

## Resume Steps
1. Read `project_rules.md`.
2. Read `version_rules.md`.
3. Run the skill QA script.
4. Inspect focused QA images before continuing.
"""
    out = folder / "handoff_summary.md"
    out.write_text(text, encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
