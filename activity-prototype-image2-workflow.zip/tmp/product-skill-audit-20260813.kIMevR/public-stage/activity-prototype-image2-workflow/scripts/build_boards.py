#!/usr/bin/env python3
import argparse
import html
import math
import re
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


STATE_RE = re.compile(r"^\d{2}_.+\.png$")
ORDER_RE = re.compile(r"(\d{2}_[^\n`]+?\.png)")
DOC_NAMES = {
    "prototype_blueprint.md",
    "mindmap.md",
    "display_order.md",
    "prompts.md",
    "global_rules.md",
    "project_rules.md",
    "version_rules.md",
    "qa_gate.md",
    "handoff_summary.md",
}
FINAL_DIR = "00_最终交付"
QA_DIR = "02_QA检查图"
MODULE_DIR = "03_模块高清图"
ASSET_DIR = "04_素材源图与调试"
ARCHIVE_DIR = "05_历史大画板归档"
DOC_DIR = "06_说明文档"


def load_font(size):
    candidates = [
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except Exception:
            pass
    return ImageFont.load_default()


def display_order_path(folder):
    for candidate in [folder / "display_order.md", folder / DOC_DIR / "display_order.md"]:
        if candidate.exists():
            return candidate
    return folder / "display_order.md"


def state_dirs(folder):
    dirs = [folder]
    dirs.extend(sorted(p for p in folder.glob("01_状态图*") if p.is_dir()))
    return dirs


def find_state(folder, name):
    for directory in state_dirs(folder):
        candidate = directory / name
        if candidate.exists():
            return candidate
    return None


def state_pngs(folder):
    found = {}
    for directory in state_dirs(folder):
        for path in sorted(directory.glob("*.png")):
            if STATE_RE.match(path.name):
                found.setdefault(path.name, path)
    return [found[name] for name in sorted(found)]


def ordered_images(folder):
    order_path = display_order_path(folder)
    if order_path.exists():
        names = ORDER_RE.findall(order_path.read_text(encoding="utf-8"))
        files = [path for name in names if (path := find_state(folder, name))]
        if files:
            return files
    return state_pngs(folder)


def modules_from_display_order(folder):
    order_path = display_order_path(folder)
    if not order_path.exists():
        return {"All": ordered_images(folder)}
    modules = {}
    current = "All"
    for line in order_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            current = line[3:].strip()
            modules.setdefault(current, [])
            continue
        match = ORDER_RE.search(line)
        if match:
            path = find_state(folder, match.group(1))
            if path:
                modules.setdefault(current, []).append(path)
    return {k: v for k, v in modules.items() if v}


def fit_text(draw, text, font, max_width):
    if draw.textlength(text, font=font) <= max_width:
        return text
    result = text
    while result and draw.textlength(result + "...", font=font) > max_width:
        result = result[:-1]
    return result + "..." if result else "..."


def make_board(groups, out_path, columns=8, scale=1.0, preview_scale=None, preview_path=None):
    sample = next(iter(next(iter(groups.values()))))
    with Image.open(sample) as im:
        sw, sh = im.size
    tw, th = int(sw * scale), int(sh * scale)
    gap = int(28 * scale)
    pad = int(44 * scale)
    title_h = int(72 * scale)
    label_h = int(42 * scale)
    title_font = load_font(max(20, int(28 * scale)))
    label_font = load_font(max(14, int(18 * scale)))

    rows_total = 0
    for files in groups.values():
        rows_total += math.ceil(len(files) / columns)
    width = pad * 2 + columns * tw + (columns - 1) * gap
    height = pad + sum(title_h + math.ceil(len(files) / columns) * (th + label_h + gap) for files in groups.values())

    board = Image.new("RGB", (width, height), "#f3f3f3")
    draw = ImageDraw.Draw(board)
    y = pad
    for module, files in groups.items():
        draw.text((pad, y), module, fill="#222222", font=title_font)
        y += title_h
        for idx, path in enumerate(files):
            row = idx // columns
            col = idx % columns
            x = pad + col * (tw + gap)
            yy = y + row * (th + label_h + gap)
            with Image.open(path).convert("RGB") as im:
                if scale != 1.0:
                    im = im.resize((tw, th), Image.Resampling.LANCZOS)
                board.paste(im, (x, yy))
            label = fit_text(draw, path.name, label_font, tw)
            draw.text((x, yy + th + int(8 * scale)), label, fill="#333333", font=label_font)
        y += math.ceil(len(files) / columns) * (th + label_h + gap)

    board.save(out_path, optimize=True)
    if preview_scale:
        preview = board.resize((int(board.width * preview_scale), int(board.height * preview_scale)), Image.Resampling.LANCZOS)
        preview_path = preview_path or out_path.with_name(out_path.stem + "_preview.png")
        preview.save(preview_path, optimize=True)
    return out_path


def rel_src(from_file, image_path):
    return Path("../" + str(image_path.relative_to(from_file.parent.parent))).as_posix()


def make_html(folder, groups, out_path):
    parts = [
        "<!doctype html><meta charset='utf-8'>",
        "<style>body{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;background:#f4f4f4;margin:24px}h2{margin:28px 0 12px}.grid{display:grid;grid-template-columns:repeat(8,852px);gap:28px;align-items:start}.card{background:white;padding:10px;border:1px solid #ddd}.card img{width:852px;height:auto;display:block}.name{font-size:14px;margin-top:8px;color:#333}</style>",
    ]
    for module, files in groups.items():
        parts.append(f"<h2>{html.escape(module)}</h2><div class='grid'>")
        for path in files:
            src = rel_src(out_path, path) if path.is_relative_to(folder) and out_path.parent != folder else path.name
            parts.append(f"<div class='card'><img src='{html.escape(src)}'><div class='name'>{html.escape(path.name)}</div></div>")
        parts.append("</div>")
    out_path.write_text("\n".join(parts), encoding="utf-8")


def mkdirs(folder):
    final = folder / FINAL_DIR
    state_count = len(state_pngs(folder))
    states = folder / f"01_状态图_{state_count}张" if state_count else folder / "01_状态图"
    dirs = {
        "final": final,
        "states": states,
        "qa": folder / QA_DIR,
        "modules": folder / MODULE_DIR,
        "assets": folder / ASSET_DIR,
        "archive": folder / ARCHIVE_DIR,
        "docs": folder / DOC_DIR,
    }
    for path in dirs.values():
        path.mkdir(exist_ok=True)
    return dirs


def move_if_needed(path, dest_dir):
    if not path.exists() or path.parent == dest_dir:
        return dest_dir / path.name
    dest = dest_dir / path.name
    if dest.exists():
        return dest
    shutil.move(str(path), str(dest))
    return dest


def organize_existing(folder):
    dirs = mkdirs(folder)
    for path in list(folder.iterdir()):
        if not path.is_file():
            continue
        if STATE_RE.match(path.name):
            move_if_needed(path, dirs["states"])
        elif path.name in DOC_NAMES:
            move_if_needed(path, dirs["docs"])
        elif path.name.startswith("qa_") and path.suffix.lower() == ".png":
            move_if_needed(path, dirs["qa"])
        elif path.name.startswith("模块高清_") and path.suffix.lower() == ".png":
            move_if_needed(path, dirs["modules"])
        elif path.name.startswith("image2_") or path.name.startswith("_debug_"):
            move_if_needed(path, dirs["assets"])
        elif path.suffix.lower() in {".png", ".html"}:
            move_if_needed(path, dirs["archive"])
    note = folder / "00_目录说明.md"
    if not note.exists():
        note.write_text(
            "# 目录说明\n\n"
            "- `00_最终交付`: 当前推荐发送和查看的最终文件。\n"
            "- `01_状态图_xx张`: 编号单页状态图。\n"
            "- `02_QA检查图`: QA 和对照检查图。\n"
            "- `03_模块高清图`: 按模块拆分的高清图。\n"
            "- `04_素材源图与调试`: 源素材和调试截图。\n"
            "- `05_历史大画板归档`: 旧版大画板、旧版预览和历史 HTML。\n"
            "- `06_说明文档`: display_order、prompts、规则和交付摘要。\n",
            encoding="utf-8",
        )
    return dirs


def main():
    parser = argparse.ArgumentParser(description="Build activity prototype boards and QA comparison boards.")
    parser.add_argument("version_dir")
    parser.add_argument("--columns", type=int, default=8)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--preview-scale", type=float, default=0.5)
    parser.add_argument("--prefix", default="activity_prototype")
    parser.add_argument("--qa", action="append", default=[], help="QA group spec: name:01,02,03")
    parser.add_argument("--no-organize", action="store_true", help="Write outputs in the version root for temporary diagnostics.")
    args = parser.parse_args()

    folder = Path(args.version_dir).expanduser().resolve()
    dirs = organize_existing(folder) if not args.no_organize else {
        "final": folder,
        "qa": folder,
    }
    groups = modules_from_display_order(folder)
    if args.no_organize:
        board_path = folder / f"{args.prefix}_module_board.png"
        preview_path = None
        html_path = folder / f"{args.prefix}_module_board.html"
    else:
        board_path = dirs["final"] / "原排版高清大画板_清晰增强.png"
        preview_path = dirs["final"] / "原排版高清预览_50%_清晰增强.png"
        html_path = dirs["final"] / f"{args.prefix}_原图清晰HTML大画板.html"
    make_board(groups, board_path, columns=args.columns, scale=args.scale, preview_scale=args.preview_scale, preview_path=preview_path)
    make_html(folder, groups, html_path)
    print(board_path)
    print(html_path)

    all_files = {p.name[:2]: p for files in groups.values() for p in files}
    for spec in args.qa:
        name, _, ids = spec.partition(":")
        selected = [all_files[i.strip()] for i in ids.split(",") if i.strip() in all_files]
        if selected:
            qa_path = dirs["qa"] / f"qa_{name}.png"
            make_board({name: selected}, qa_path, columns=min(args.columns, len(selected)), scale=args.scale, preview_scale=None)
            print(qa_path)


if __name__ == "__main__":
    main()
