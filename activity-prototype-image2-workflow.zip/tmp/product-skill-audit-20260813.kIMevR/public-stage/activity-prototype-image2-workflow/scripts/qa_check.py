#!/usr/bin/env python3
import argparse
import re
import sys
from collections import Counter
from pathlib import Path

from PIL import Image


STATE_RE = re.compile(r"^\d{2}_.+\.png$")
DOC_DIR = "06_说明文档"


def split_csv(value):
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def state_dirs(folder):
    dirs = [folder]
    dirs.extend(sorted(p for p in folder.glob("01_状态图*") if p.is_dir()))
    return dirs


def state_pngs(folder):
    found = {}
    for directory in state_dirs(folder):
        for path in sorted(directory.glob("*.png")):
            if STATE_RE.match(path.name):
                found.setdefault(path.name, path)
    return [found[name] for name in sorted(found)]


def doc_path(folder, name):
    for candidate in [folder / name, folder / DOC_DIR / name]:
        if candidate.exists():
            return candidate
    return folder / name


def display_order_names(path):
    if not path.exists():
        return []
    names = re.findall(r"(\d{2}_[^\n`]+?\.png)", path.read_text(encoding="utf-8"))
    return [name.strip() for name in names]


def prompt_names(path):
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="ignore")
    return [name.strip() for name in re.findall(r"^##\s+(\d{2}_[^\n`]+?\.png)\s*$", text, re.M)]


def blueprint_modules(path):
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="ignore")
    modules = []
    for match in re.finditer(r"^\|\s*\d{2}\s*\|\s*[^|]+?\.png\s*\|\s*([^|]+?)\s*\|", text, re.M):
        module = match.group(1).strip()
        if module not in modules:
            modules.append(module)
    return modules


def main():
    parser = argparse.ArgumentParser(description="QA checks for activity prototype image folders.")
    parser.add_argument("version_dir")
    parser.add_argument("--expected-count", type=int)
    parser.add_argument("--forbidden-terms", default="")
    parser.add_argument("--required-files", default="")
    parser.add_argument("--check-prompts", action="store_true")
    parser.add_argument("--check-mindmap", action="store_true")
    args = parser.parse_args()

    folder = Path(args.version_dir).expanduser().resolve()
    errors = []
    warnings = []

    if not folder.exists():
        print(f"ERROR: folder does not exist: {folder}", file=sys.stderr)
        return 2

    states = state_pngs(folder)
    if args.expected_count is not None and len(states) != args.expected_count:
        errors.append(f"state count {len(states)} != expected {args.expected_count}")
    if not states:
        errors.append("no state PNGs found")

    dims = []
    for png in states:
        try:
            with Image.open(png) as im:
                dims.append((png.name, im.size))
        except Exception as exc:
            errors.append(f"cannot read {png.name}: {exc}")

    counts = Counter(size for _, size in dims)
    if len(counts) > 1:
        detail = ", ".join(f"{size}:{count}" for size, count in counts.items())
        errors.append(f"inconsistent state dimensions: {detail}")

    order_path = doc_path(folder, "display_order.md")
    ordered = display_order_names(order_path)
    state_names = [p.name for p in states]
    missing = sorted(set(state_names) - set(ordered))
    extra = sorted(set(ordered) - set(state_names))
    dupes = sorted(name for name, count in Counter(ordered).items() if count > 1)
    if missing:
        errors.append("display_order missing: " + ", ".join(missing))
    if extra:
        errors.append("display_order extra: " + ", ".join(extra))
    if dupes:
        errors.append("display_order duplicates: " + ", ".join(dupes))

    if args.check_prompts:
        prompts_path = doc_path(folder, "prompts.md")
        prompts = prompt_names(prompts_path)
        prompt_missing = sorted(set(state_names) - set(prompts))
        prompt_extra = sorted(set(prompts) - set(state_names))
        prompt_dupes = sorted(name for name, count in Counter(prompts).items() if count > 1)
        if prompt_missing:
            errors.append("prompts missing: " + ", ".join(prompt_missing))
        if prompt_extra:
            errors.append("prompts extra: " + ", ".join(prompt_extra))
        if prompt_dupes:
            errors.append("prompts duplicates: " + ", ".join(prompt_dupes))

    if args.check_mindmap:
        mindmap_path = doc_path(folder, "mindmap.md")
        if not mindmap_path.exists():
            errors.append("mindmap.md missing")
        else:
            mindmap_text = mindmap_path.read_text(encoding="utf-8", errors="ignore")
            missing_modules = [module for module in blueprint_modules(doc_path(folder, "prototype_blueprint.md")) if module not in mindmap_text]
            if missing_modules:
                errors.append("mindmap missing modules: " + ", ".join(missing_modules))

    for rel in split_csv(args.required_files):
        candidates = [folder / rel]
        if "/" not in rel and rel in {"prototype_blueprint.md", "mindmap.md", "display_order.md", "prompts.md", "global_rules.md", "project_rules.md", "version_rules.md", "qa_gate.md", "handoff_summary.md"}:
            candidates.append(doc_path(folder, rel))
        if not any(path.exists() for path in candidates):
            errors.append(f"required file missing: {rel}")

    text_files = [
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() in {".md", ".html", ".txt"}
    ]
    docs_dir = folder / DOC_DIR
    if docs_dir.exists():
        text_files.extend(
            p for p in docs_dir.iterdir()
            if p.is_file() and p.suffix.lower() in {".md", ".html", ".txt"}
        )
    for term in split_csv(args.forbidden_terms):
        hits = []
        for path in text_files:
            try:
                if term in path.read_text(encoding="utf-8", errors="ignore"):
                    hits.append(path.name)
            except Exception:
                warnings.append(f"skipped text scan: {path.name}")
        if hits:
            errors.append(f"forbidden term {term!r} found in: {', '.join(hits)}")

    print(f"Folder: {folder}")
    print(f"State PNGs: {len(states)}")
    if dims:
        print("Dimensions: " + ", ".join(f"{size} x{count}" for size, count in counts.items()))
    print(f"Display order entries: {len(ordered)}")
    if args.check_prompts:
        print(f"Prompt entries: {len(prompt_names(doc_path(folder, 'prompts.md')))}")
    if args.check_mindmap:
        print("Mind map: " + ("present" if doc_path(folder, "mindmap.md").exists() else "missing"))
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")
    if errors:
        print("FAILED:")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
